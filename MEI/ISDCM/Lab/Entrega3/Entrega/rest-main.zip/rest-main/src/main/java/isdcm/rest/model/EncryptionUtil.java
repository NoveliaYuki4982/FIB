package isdcm.rest.model;

import java.io.IOException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class EncryptionUtil {

    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private static final String SECRET_KEY_STRING = "ThisIsASecretKeyForLowbudgetNetflix";
    private static final String INIT_VECTOR_STRING = "ThisIsAnInitVec1";

    private static SecretKey secretKey;
    private static IvParameterSpec ivParameterSpec;

    static {
        try {
            byte[] keyBytes = new byte[16];
            byte[] ivBytes = new byte[16];

            byte[] skStringBytes = SECRET_KEY_STRING.getBytes(StandardCharsets.UTF_8);
            System.arraycopy(skStringBytes, 0, keyBytes, 0, Math.min(skStringBytes.length, keyBytes.length));
            
            byte[] ivStringBytes = INIT_VECTOR_STRING.getBytes(StandardCharsets.UTF_8);
            System.arraycopy(ivStringBytes, 0, ivBytes, 0, Math.min(ivStringBytes.length, ivBytes.length));

            secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
            ivParameterSpec = new IvParameterSpec(ivBytes);
        } catch (Exception e) {
            throw new RuntimeException("Error initializing encryption keys", e);
        }
    }

    public static void encrypt(InputStream inputStream, OutputStream outputStream) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
        
        try (CipherOutputStream cos = new CipherOutputStream(outputStream, cipher)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                cos.write(buffer, 0, bytesRead);
            }
        }
    }

    public static void decrypt(InputStream inputStream, OutputStream outputStream) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);

        try (CipherInputStream cis = new CipherInputStream(inputStream, cipher)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = cis.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }
    }
}
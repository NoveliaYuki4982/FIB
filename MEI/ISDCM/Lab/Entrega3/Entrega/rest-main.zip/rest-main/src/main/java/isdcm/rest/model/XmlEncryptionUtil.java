package isdcm.rest.model;

import org.apache.xml.security.encryption.XMLCipher;
import org.apache.xml.security.utils.EncryptionConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class XmlEncryptionUtil {

    private static final String XML_ENCRYPTION_ALGORITHM = XMLCipher.AES_128;
    private static final String KEY_ALGORITHM = "AES";
    private static final String SECRET_KEY_STRING = "ThisIsASecretKeyForLowbudgetXML";

    static {
        org.apache.xml.security.Init.init();
    }

    private static SecretKey getSecretKey() {
        byte[] keyBytes = new byte[16];
        byte[] skStringBytes = SECRET_KEY_STRING.getBytes(StandardCharsets.UTF_8);
        System.arraycopy(skStringBytes, 0, keyBytes, 0, Math.min(skStringBytes.length, keyBytes.length));
        return new SecretKeySpec(keyBytes, KEY_ALGORITHM);
    }

    public static void encryptDocument(Document doc, OutputStream outputStream, String elementToEncryptTagName) throws Exception {
        XMLCipher xmlCipher = XMLCipher.getInstance(XML_ENCRYPTION_ALGORITHM);
        SecretKey secretKey = getSecretKey();
        xmlCipher.init(XMLCipher.ENCRYPT_MODE, secretKey);

        Element elementToEncrypt = (Element) doc.getElementsByTagName(elementToEncryptTagName).item(0);
        if (elementToEncrypt == null) {
            throw new RuntimeException("Element to encrypt '" + elementToEncryptTagName + "' not found in XML document.");
        }
        
        Document encryptedDoc = xmlCipher.doFinal(doc, elementToEncrypt, false);

        TransformerFactory tf = TransformerFactory.newInstance();
        try {
            tf.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
        } catch (javax.xml.transform.TransformerConfigurationException e) {
            System.err.println("Warning: TransformerFactory does not support FEATURE_SECURE_PROCESSING: " + e.getMessage());
        }

        Transformer transformer = tf.newTransformer();
        transformer.transform(new DOMSource(encryptedDoc != null ? encryptedDoc : doc), new StreamResult(outputStream));
    }

    public static Document decryptDocument(InputStream inputStream) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
        dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        dbf.setXIncludeAware(false);
        dbf.setExpandEntityReferences(false);
         try {
             dbf.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
         } catch (javax.xml.parsers.ParserConfigurationException e) {
              System.err.println("Warning: DocumentBuilderFactory does not support FEATURE_SECURE_PROCESSING for decryption: " + e.getMessage());
         }


        DocumentBuilder builder = dbf.newDocumentBuilder();
        Document encryptedDoc = builder.parse(inputStream);

        Element encryptedDataElement = (Element) encryptedDoc.getElementsByTagNameNS(EncryptionConstants.EncryptionSpecNS, EncryptionConstants._TAG_ENCRYPTEDDATA).item(0);
        if (encryptedDataElement == null) {
            if (EncryptionConstants.EncryptionSpecNS.equals(encryptedDoc.getDocumentElement().getNamespaceURI()) &&
                EncryptionConstants._TAG_ENCRYPTEDDATA.equals(encryptedDoc.getDocumentElement().getLocalName())) {
                encryptedDataElement = encryptedDoc.getDocumentElement();
            } else {
                 throw new RuntimeException("No EncryptedData element found in the XML document.");
            }
        }
        
        XMLCipher xmlCipher = XMLCipher.getInstance();
        SecretKey secretKey = getSecretKey();
        xmlCipher.init(XMLCipher.DECRYPT_MODE, secretKey);
        
        xmlCipher.doFinal(encryptedDoc, encryptedDataElement);

        return encryptedDoc;
    }
}
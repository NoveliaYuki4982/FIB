package isdcm.rest.security;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import org.jose4j.keys.AesKey;

public class SecurityConstants {

    public static final String JWT_JWS_SECRET_STRING = "YourSuperSecretAndLongEnoughSigningKeyForHS512LowbudgetNetflixRestService";
    public static final byte[] JWT_JWS_SECRET_KEY_BYTES = JWT_JWS_SECRET_STRING.getBytes(StandardCharsets.UTF_8);

    private static final String JWE_SECRET_STRING = "AnotherDifferentSecretKeyForJWEAES256GCMContentEncrypt";
    
    private static byte[] getJweEncryptionKeyBytes() {
        byte[] fullKey = JWE_SECRET_STRING.getBytes(StandardCharsets.UTF_8);
        byte[] keyBytes32 = new byte[32];
        System.arraycopy(fullKey, 0, keyBytes32, 0, Math.min(fullKey.length, 32));
        if (fullKey.length < 32) {
            for (int i = fullKey.length; i < 32; i++) {
                keyBytes32[i] = 0;
            }
        }
        return keyBytes32;
    }
    public static final Key JWE_ENCRYPTION_KEY_JOSE4J = new AesKey(getJweEncryptionKeyBytes());

    public static final String API_KEY_FOR_JWT = "g5KlCZx8t5hx0xcqLDI87V5hM5vMQeIC6qfWA8vaoOj7hnbDsztImSpuoHEItodDXvfYSEjWk10rkX62mUVqdR9ces2KS59nJvoZIimp5xATmkjOlmBBlrirv0goBm8t";
    public static final long JWT_EXPIRATION_MS = 3600000;
}
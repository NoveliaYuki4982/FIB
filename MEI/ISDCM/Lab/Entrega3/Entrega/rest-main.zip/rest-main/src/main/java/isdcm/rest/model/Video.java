package isdcm.rest.model;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Video {

    private Document generateMetadataXmlDocument(VideoEntity video, UserEntity authorUser) throws Exception {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        docFactory.setNamespaceAware(true);
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.newDocument();

        Element didlElement = doc.createElementNS("urn:mpeg:mpeg21:2002:02-DIDL-NS", "DIDL");
        doc.appendChild(didlElement);
        didlElement.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
        didlElement.setAttributeNS("http://www.w3.org/2001/XMLSchema-instance", "xsi:schemaLocation", "urn:mpeg:mpeg21:2002:02-DIDL-NS didl.xsd");

        Element itemElement = doc.createElement("Item");
        didlElement.appendChild(itemElement);
        Element componentElement = doc.createElement("Component");
        itemElement.appendChild(componentElement);
        Element descriptorElement = doc.createElement("Descriptor");
        componentElement.appendChild(descriptorElement);
        Element statementElement = doc.createElement("Statement");
        statementElement.setAttribute("mimeType", "text/xml");
        descriptorElement.appendChild(statementElement);
        Element metadataElement = doc.createElement("metadata");
        statementElement.appendChild(metadataElement);

        Element idElement = doc.createElement("id");
        idElement.appendChild(doc.createTextNode(String.valueOf(video.getVideoId())));
        metadataElement.appendChild(idElement);

        Element tituloElement = doc.createElement("titulo");
        tituloElement.appendChild(doc.createTextNode(video.getTitle() != null ? video.getTitle() : ""));
        metadataElement.appendChild(tituloElement);

        Element autorElement = doc.createElement("autor");
        autorElement.appendChild(doc.createTextNode(authorUser != null && authorUser.getUsername() != null ? authorUser.getUsername() : "N/A"));
        metadataElement.appendChild(autorElement);

        Element anyoElement = doc.createElement("anyo");
        anyoElement.appendChild(doc.createTextNode(video.getCreationDateInternal() != null ? String.valueOf(video.getCreationYear()) : "N/A"));
        metadataElement.appendChild(anyoElement);

        Element duracionElement = doc.createElement("duracion");
        duracionElement.appendChild(doc.createTextNode(String.valueOf(video.getLength())));
        metadataElement.appendChild(duracionElement);

        Element reproduccionesElement = doc.createElement("reproducciones");
        reproduccionesElement.appendChild(doc.createTextNode(String.valueOf(video.getReproductions())));
        metadataElement.appendChild(reproduccionesElement);

        Element descripcionElement = doc.createElement("descripcion");
        descripcionElement.appendChild(doc.createTextNode(video.getDescription() != null ? video.getDescription() : ""));
        metadataElement.appendChild(descripcionElement);

        Element resourceElement = doc.createElement("Resource");
        resourceElement.setAttribute("ref", video.getFilePath() != null ? video.getFilePath() : "");
        resourceElement.setAttribute("mimeType", "video/" + (video.getFormat() != null ? video.getFormat() : ""));
        componentElement.appendChild(resourceElement);

        return doc;
    }
    
    public void addVideo(VideoEntity video) throws SQLException {
        System.err.println("[VideoDAO.addVideo (lowbudgetnetflix)] Persisting metadata for video title: " + video.getTitle());
        String sql = "INSERT INTO videos (title, author, length, description, format, filePath, metadataFilePath, creationDate) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            ps.setString(1, video.getTitle());
            ps.setInt(2, video.getAuthor());
            ps.setInt(3, video.getLength());
            ps.setString(4, video.getDescription());
            ps.setString(5, video.getFormat());
            ps.setString(6, video.getFilePath());
            ps.setString(7, video.getMetadataFilePath());
            
            int affectedRows = ps.executeUpdate();
            System.err.println("[VideoDAO.addVideo (lowbudgetnetflix)] DB insert affected rows: " + affectedRows);

            if (affectedRows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        video.setVideoId(rs.getInt(1));
                        System.err.println("[VideoDAO.addVideo (lowbudgetnetflix)] Generated Video ID: " + video.getVideoId());
                        VideoEntity persistedVideo = getVideoById(video.getVideoId());
                        if (persistedVideo != null && persistedVideo.getCreationDateInternal() != null) {
                            video.setCreationDate(persistedVideo.getCreationDateInternal());
                            System.err.println("[VideoDAO.addVideo (lowbudgetnetflix)] Updated creation date from DB: " + video.getCreationDateInternal());
                        } else {
                             System.err.println("[VideoDAO.addVideo (lowbudgetnetflix)] Could not accurately fetch DB creation date after insert for video ID: " + video.getVideoId());
                             if (video.getCreationDateInternal() == null) {
                                 video.setCreationDate(new java.sql.Timestamp(System.currentTimeMillis()));
                             }
                        }
                    } else {
                        System.err.println("[VideoDAO.addVideo (lowbudgetnetflix)] Failed to retrieve generated videoId.");
                        throw new SQLException("Failed to retrieve generated videoId.");
                    }
                }
            } else {
                 System.err.println("[VideoDAO.addVideo (lowbudgetnetflix)] DB insert failed, no rows affected.");
                 throw new SQLException("Creating video failed, no rows affected in database.");
            }
        } catch (SQLException e) {
            System.err.println("[VideoDAO.addVideo (lowbudgetnetflix)] SQLException during DB operation: " + e.getMessage());
            e.printStackTrace(System.err);
            throw e;
        }
    }
        
    public void incrementReproductions(int videoId, String metadataPath) throws SQLException, IOException {
        VideoEntity video = getVideoById(videoId);
        if (video == null || video.getMetadataFilePath() == null) {
            throw new SQLException("Video or its metadata path not found with ID: " + videoId);
        }

        String sql = "UPDATE videos SET reproductions = reproductions + 1 WHERE videoId = ?";
        int newReproductionsCount;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, videoId);
            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Failed to update reproductions in DB for video ID: " + videoId);
            }
            newReproductionsCount = video.getReproductions() + 1;
        }
        
        Path encryptedMetadataPath = Paths.get(metadataPath, video.getMetadataFilePath());
        if (!Files.exists(encryptedMetadataPath)) {
            System.err.println("Encrypted metadata file not found for update: " + encryptedMetadataPath.toString() + ". Skipping XML update.");
            return;
        }

        Document decryptedDoc;
        try (InputStream fis = Files.newInputStream(encryptedMetadataPath)) {
            decryptedDoc = XmlEncryptionUtil.decryptDocument(fis);
        } catch (Exception e) {
            throw new IOException("Failed to decrypt metadata XML for view count update.", e);
        }

        try {
            NodeList reproductionsNodes = decryptedDoc.getElementsByTagName("reproducciones");
            if (reproductionsNodes.getLength() > 0) {
                reproductionsNodes.item(0).setTextContent(String.valueOf(newReproductionsCount));
            } else {
                 System.err.println("Could not find <reproducciones> tag in decrypted metadata XML for video " + videoId);
                 return;
            }
            
            try (OutputStream fos = Files.newOutputStream(encryptedMetadataPath)) {
                XmlEncryptionUtil.encryptDocument(decryptedDoc, fos, "Item");
            }

        } catch (Exception e) {
            throw new IOException("Error processing or re-encrypting XML for view count update.", e);
        }
    }

    public InputStream getDecryptedMetadataXmlStream(int videoId, String metadataPath) throws SQLException, IOException {
        VideoEntity video = getVideoById(videoId);
        if (video == null || video.getMetadataFilePath() == null) {
            throw new IOException("Video or metadata file path not found for ID: " + videoId);
        }
        Path encryptedXmlPath = Paths.get(metadataPath, video.getMetadataFilePath());
        if (!Files.exists(encryptedXmlPath)) {
            throw new IOException("Encrypted metadata file does not exist: " + encryptedXmlPath);
        }

        Document decryptedDoc;
        try (InputStream fis = Files.newInputStream(encryptedXmlPath)) {
            decryptedDoc = XmlEncryptionUtil.decryptDocument(fis);
        } catch (Exception e) {
            System.err.println("Error during XML decryption for videoId " + videoId + ": " + e.getMessage());
            e.printStackTrace(System.err);
            throw new IOException("Failed to decrypt metadata XML.", e);
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            try {
                tf.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
            } catch (javax.xml.transform.TransformerConfigurationException e) {
                System.err.println("Warning: TransformerFactory does not support FEATURE_SECURE_PROCESSING: " + e.getMessage());
            }

            Transformer transformer = tf.newTransformer();
            transformer.transform(new DOMSource(decryptedDoc), new StreamResult(baos));
        } catch (Exception e) {
            System.err.println("Error serializing decrypted XML for videoId " + videoId + ": " + e.getMessage());
            e.printStackTrace(System.err);
            throw new IOException("Failed to serialize decrypted XML document to stream.", e);
        }
        return new ByteArrayInputStream(baos.toByteArray());
    }
    
    public List<VideoEntity> searchVideos(
            String name, String author, String description,
            Integer year, Integer month, Integer day,
            String orderBy, String orderDir) throws SQLException, IllegalArgumentException {

        List<VideoEntity> videos = new ArrayList<>();
        StringBuilder sqlBuilder = new StringBuilder("SELECT v.*, u.username FROM videos v JOIN users u ON v.author = u.userId WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (name != null && !name.isEmpty()) {
            sqlBuilder.append(" AND LOWER(v.title) LIKE ?");
            params.add("%" + name.toLowerCase() + "%");
        }

        if (author != null && !author.isEmpty()) {
            sqlBuilder.append(" AND LOWER(u.username) LIKE ?");
            params.add("%" + author.toLowerCase() + "%");
        }
        
        if (description != null && !description.isEmpty()) {
            sqlBuilder.append(" AND LOWER(v.description) LIKE ?");
            params.add("%" + description.toLowerCase() + "%");
        }

        if (year != null) {
            sqlBuilder.append(" AND YEAR(v.creationDate) = ?");
            params.add(year);
        }

        if (month != null) {
            sqlBuilder.append(" AND MONTH(v.creationDate) = ?");
            params.add(month);
        }

        if (day != null) {
            sqlBuilder.append(" AND DAY(v.creationDate) = ?");
            params.add(day);
        }

        if (orderBy != null && !orderBy.isEmpty()) {
            String sortColumn;
            switch (orderBy.toLowerCase()) {
                case "views":
                    sortColumn = "v.reproductions";
                    break;
                case "releasedate":
                    sortColumn = "v.creationDate";
                    break;
                case "title":
                    sortColumn = "v.title";
                    break;
                case "author":
                    sortColumn = "u.username";
                    break;
                default:
                    throw new IllegalArgumentException("Invalid orderBy parameter: " + orderBy +
                            ". Allowed values are: views, releaseDate, title, author.");
            }

            String direction = "ASC";
            if (orderDir != null) {
                if (orderDir.equalsIgnoreCase("DESC")) {
                    direction = "DESC";
                } else if (!orderDir.equalsIgnoreCase("ASC")) {
                    throw new IllegalArgumentException("Invalid orderDir parameter: " + orderDir +
                            ". Allowed values are: ASC, DESC.");
                }
            }
            sqlBuilder.append(" ORDER BY ").append(sortColumn).append(" ").append(direction);
        } else {
            sqlBuilder.append(" ORDER BY v.creationDate DESC");
        }


        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sqlBuilder.toString())) {

            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    VideoEntity video = mapRowToVideoEntity(rs);
                    videos.add(video);
                }
            }
        }
        return videos;
    }

    public List<VideoEntity> getAllVideos() throws SQLException {
        return searchVideos(null, null, null, null, null, null, "releaseDate", "DESC");
    }
    
    public VideoEntity getVideoById(int videoId) throws SQLException {
        String sql = "SELECT v.*, u.username FROM videos v JOIN users u ON v.author = u.userId WHERE v.videoId = ?";
        VideoEntity video = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, videoId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    video = mapRowToVideoEntity(rs);
                }
            }
        }
        return video;
    }

    public boolean deleteVideo(int videoId, String videoPathBase, String metadataPathBase) throws SQLException, IOException {
        VideoEntity video = getVideoById(videoId);
        if (video == null) {
            return false;
        }

        String sql = "DELETE FROM videos WHERE videoId = ?";
        int rowsAffected;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, videoId);
            rowsAffected = ps.executeUpdate();
        }

        if (rowsAffected > 0) {
            if (video.getFilePath() != null && !video.getFilePath().isEmpty()) {
                Files.deleteIfExists(Paths.get(videoPathBase, video.getFilePath()));
            }
            if (video.getMetadataFilePath() != null && !video.getMetadataFilePath().isEmpty()) {
                Files.deleteIfExists(Paths.get(metadataPathBase, video.getMetadataFilePath()));
            }
            return true;
        }
        return false;
    }

    public boolean updateVideoDetails(int videoId, String title, String description) throws SQLException {
        String sql = "UPDATE videos SET title = ?, description = ? WHERE videoId = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setInt(3, videoId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }

    private VideoEntity mapRowToVideoEntity(ResultSet rs) throws SQLException {
        VideoEntity video = new VideoEntity();
        video.setVideoId(rs.getInt("videoId"));
        video.setTitle(rs.getString("title"));
        video.setAuthor(rs.getInt("author"));
        video.setAuthorUsername(rs.getString("username"));
        video.setCreationDate(rs.getTimestamp("creationDate"));
        video.setLength(rs.getInt("length"));
        video.setReproductions(rs.getInt("reproductions"));
        video.setDescription(rs.getString("description"));
        video.setFormat(rs.getString("format"));
        video.setFilePath(rs.getString("filePath"));
        
        boolean metadataFilePathExists = false;
        for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
            if ("metadatafilepath".equalsIgnoreCase(rs.getMetaData().getColumnName(i))) {
                metadataFilePathExists = true;
                break;
            }
        }
        if (metadataFilePathExists) {
             String metaPath = rs.getString("metadataFilePath");
             if(metaPath != null) video.setMetadataFilePath(metaPath);
        }
        return video;
    }
}
package isdcm.rest.resources;

import isdcm.rest.model.Video;
import isdcm.rest.model.VideoEntity;
import isdcm.rest.model.User;
import isdcm.rest.model.UserEntity;

import isdcm.rest.model.EncryptionUtil;
import isdcm.rest.model.XmlEncryptionUtil;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.StreamingOutput;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.core.Context;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.lang.JoseException;

import isdcm.rest.security.SecurityConstants;

@Path("/videos")
public class VideoRestService {

    private final Video videoDAO = new Video();
    private final User userDAO = new User();

    @Context
    private ServletContext servletContext;

    private Document generateMetadataXmlDocument(VideoEntity video, String authorUsernameForXml) throws Exception {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        docFactory.setNamespaceAware(true);
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.newDocument();

        Element didlElement = doc.createElementNS("urn:mpeg:mpeg21:2002:02-DIDL-NS", "DIDL");
        doc.appendChild(didlElement);
        didlElement.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
        didlElement.setAttributeNS("http://www.w3.org/2001/XMLSchema-instance", "xsi:schemaLocation", "urn:mpeg:mpeg21:2002:02-DIDL-NS didl.xsd");

        Element itemElement = doc.createElement("Item");
        didlElement.appendChild(itemElement);
        Element componentElement = doc.createElement("Component");
        itemElement.appendChild(componentElement);
        Element descriptorElement = doc.createElement("Descriptor");
        componentElement.appendChild(descriptorElement);
        Element statementElement = doc.createElement("Statement");
        statementElement.setAttribute("mimeType", "text/xml");
        descriptorElement.appendChild(statementElement);
        Element metadataElement = doc.createElement("metadata");
        statementElement.appendChild(metadataElement);

        Element idElement = doc.createElement("id");
        idElement.appendChild(doc.createTextNode(String.valueOf(video.getVideoId())));
        metadataElement.appendChild(idElement);
        Element tituloElement = doc.createElement("titulo");
        tituloElement.appendChild(doc.createTextNode(video.getTitle() != null ? video.getTitle() : ""));
        metadataElement.appendChild(tituloElement);
        Element autorElement = doc.createElement("autor");
        autorElement.appendChild(doc.createTextNode(authorUsernameForXml != null ? authorUsernameForXml : "N/A"));
        metadataElement.appendChild(autorElement);
        
        int year = 0;
        Object creationDateRaw = video.getCreationDate();
        Date creationDateObj = null;

        if (creationDateRaw instanceof String) {
            String creationDateAsString = (String) creationDateRaw;
            if (creationDateAsString != null && !creationDateAsString.trim().isEmpty()) {
                try {
                    creationDateObj = java.sql.Timestamp.valueOf(creationDateAsString);
                } catch (IllegalArgumentException e) {
                    try {
                        creationDateObj = java.sql.Date.valueOf(creationDateAsString);
                    } catch (IllegalArgumentException e2) {
                         try {
                             SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
                             creationDateObj = sdf.parse(creationDateAsString);
                         } catch (ParseException e3) {
                              System.err.println("Warning: Could not parse creation date string '" + creationDateAsString + "'. Year will be N/A. Error: " + e3.getMessage());
                         }
                    }
                }
            }
        } else if (creationDateRaw instanceof Date) {
            creationDateObj = (Date) creationDateRaw;
        }
        
        if (creationDateObj != null) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(creationDateObj);
            year = cal.get(Calendar.YEAR);
        }
        Element anyoElement = doc.createElement("anyo");
        anyoElement.appendChild(doc.createTextNode(year != 0 ? String.valueOf(year) : "N/A"));
        metadataElement.appendChild(anyoElement);

        Element duracionElement = doc.createElement("duracion");
        duracionElement.appendChild(doc.createTextNode(String.valueOf(video.getLength())));
        metadataElement.appendChild(duracionElement);
        Element reproduccionesElement = doc.createElement("reproducciones");
        reproduccionesElement.appendChild(doc.createTextNode(String.valueOf(video.getReproductions())));
        metadataElement.appendChild(reproduccionesElement);
        Element resourceElement = doc.createElement("Resource");
        resourceElement.setAttribute("ref", video.getFilePath() != null ? video.getFilePath() : "");
        resourceElement.setAttribute("mimeType", "video/" + (video.getFormat() != null ? video.getFormat() : ""));
        componentElement.appendChild(resourceElement);
        return doc;
    }
    
    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response loginUser(@FormParam("username") String username, @FormParam("password") String password) {
        try {
            UserEntity user = userDAO.authenticateUser(username, password);
            if (user != null) {
                long nowMillis = System.currentTimeMillis();
                Date now = new Date(nowMillis);
                long expMillis = nowMillis + SecurityConstants.JWT_EXPIRATION_MS;
                Date exp = new Date(expMillis);

                Map<String, Object> claims = new HashMap<>();
                claims.put("apiKey", SecurityConstants.API_KEY_FOR_JWT);
                claims.put("userId", user.getUserId());
                
                String jwsTokenString = Jwts.builder()
                    .setClaims(claims)
                    .setSubject(user.getUsername())
                    .setIssuedAt(now)
                    .setExpiration(exp)
                    .signWith(SignatureAlgorithm.HS512, SecurityConstants.JWT_JWS_SECRET_KEY_BYTES)
                    .compact();

                JsonWebEncryption jwe = new JsonWebEncryption();
                jwe.setPlaintext(jwsTokenString);
                jwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.DIRECT);
                jwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_256_GCM);
                jwe.setKey(SecurityConstants.JWE_ENCRYPTION_KEY_JOSE4J);
                jwe.setContentTypeHeaderValue("JWT");
                String finalEncryptedToken = jwe.getCompactSerialization();

                Map<String, Object> responseData = new HashMap<>();
                responseData.put("token", finalEncryptedToken);
                responseData.put("expiresAt", expMillis);
                responseData.put("username", user.getUsername());

                return Response.ok(responseData).build();
            } else {
                return Response.status(Response.Status.UNAUTHORIZED).entity("{\"error\":\"Invalid username or password\"}").build();
            }
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Database error during login: " + e.getMessage() + "\"}").build();
        } catch (JoseException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Error creating secure token (JWE): " + e.getMessage() + "\"}").build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"An unexpected error occurred: " + e.getMessage() + "\"}").build();
        }
    }
    
    @GET
    @Path("/debug-jws")
    @Produces(MediaType.TEXT_PLAIN)
    public Response getDebugJws(@HeaderParam("Authorization") String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return Response.status(Response.Status.BAD_REQUEST)
                           .entity("Authorization header with Bearer token is required.")
                           .build();
        }

        String jweTokenString = authHeader.substring("Bearer ".length());

        try {
            JsonWebEncryption jwe = new JsonWebEncryption();
            jwe.setKey(SecurityConstants.JWE_ENCRYPTION_KEY_JOSE4J);
            jwe.setCompactSerialization(jweTokenString);
            
            String innerJwsString = jwe.getPlaintextString();
            
            if (innerJwsString == null || innerJwsString.isEmpty()) {
                 return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                               .entity("Decrypted content is empty.")
                               .build();
            }

            return Response.ok(innerJwsString)
                           .type("application/jwt")
                           .build();

        } catch (JoseException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity("Failed to decrypt JWE token: " + e.getMessage())
                           .build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity("An unexpected error occurred during JWE decryption: " + e.getMessage())
                           .build();
        }
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response searchVideos(
            @QueryParam("name") String name,
            @QueryParam("author") String author,
            @QueryParam("description") String description,
            @QueryParam("year") Integer year,
            @QueryParam("month") Integer month,
            @QueryParam("day") Integer day,
            @QueryParam("orderBy") String orderBy,
            @QueryParam("orderDir") String orderDir) {
        try {
            List<VideoEntity> videos = videoDAO.searchVideos(name, author, description, year, month, day, orderBy, orderDir);
            return Response.ok(videos).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity("{\"error\":\"Invalid query parameter: " + e.getMessage() + "\"}").build();
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Database error: " + e.getMessage() + "\"}").build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Unexpected error: " + e.getMessage() + "\"}").build();
        }
    }

    @POST
    @Path("/upload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    public Response uploadVideo(
            @FormDataParam("title") String title,
            @FormDataParam("description") String description,
            @FormDataParam("length") int length,
            @FormDataParam("author") int authorId,
            @FormDataParam("videoFile") InputStream uploadedInputStream,
            @FormDataParam("videoFile") FormDataContentDisposition fileDetail) {

        if (title == null || title.trim().isEmpty() || length <= 0 || authorId <= 0 || uploadedInputStream == null || fileDetail == null || fileDetail.getFileName() == null || fileDetail.getFileName().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST).entity("{\"error\":\"Missing or invalid parameters.\"}").build();
        }

        String videoUploadPath = servletContext.getInitParameter("uploadDirectory");
        String metadataUploadPath = servletContext.getInitParameter("metadataDirectory");

        if (videoUploadPath == null) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Video upload directory not configured.\"}").build();
        }
        if (metadataUploadPath == null) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Metadata directory not configured.\"}").build();
        }

        File videoUploadDirFile = new File(videoUploadPath);
        if (!videoUploadDirFile.exists()) {
            videoUploadDirFile.mkdirs();
        }
        File metadataUploadDirFile = new File(metadataUploadPath);
        if (!metadataUploadDirFile.exists()) {
            metadataUploadDirFile.mkdirs();
        }

        String originalFileName = fileDetail.getFileName();
        String extension = "";
        int i = originalFileName.lastIndexOf('.');
        if (i > 0) {
            extension = originalFileName.substring(i+1).toLowerCase();
        }
        if (extension.isEmpty()){
            return Response.status(Response.Status.BAD_REQUEST).entity("{\"error\":\"File has no extension.\"}").build();
        }

        String baseName = UUID.randomUUID().toString();
        String encryptedVideoFileName = baseName + "_video.enc";
        String encryptedMetadataFileName = baseName + "_meta.xml.enc";

        java.nio.file.Path encryptedVideoPath = Paths.get(videoUploadPath, encryptedVideoFileName);
        java.nio.file.Path encryptedMetadataPath = Paths.get(metadataUploadPath, encryptedMetadataFileName);

        VideoEntity video = new VideoEntity();
        video.setTitle(title);
        video.setAuthor(authorId);
        video.setLength(length);
        video.setDescription(description);
        video.setFormat(extension);
        video.setFilePath(encryptedVideoFileName);
        video.setMetadataFilePath(encryptedMetadataFileName);

        String authorUsernameForXml = "User" + authorId;
        UserEntity authorUser = null;
        try {
            authorUser = userDAO.getUserById(authorId);
            if (authorUser != null && authorUser.getUsername() != null) {
                authorUsernameForXml = authorUser.getUsername();
                video.setAuthorUsername(authorUsernameForXml);
            } else if (authorUser == null) {
                System.err.println("Warning: Author user not found for ID: " + authorId + " for REST upload.");
            }
        } catch (SQLException e) {
           System.err.println("Could not fetch author user details for XML (REST upload), using ID as fallback: " + e.getMessage());
        }

        try {
            try (OutputStream fosVideo = Files.newOutputStream(encryptedVideoPath)) {
                EncryptionUtil.encrypt(uploadedInputStream, fosVideo);
            }

            videoDAO.addVideo(video);

            if (video.getVideoId() == 0) {
                System.err.println("CRITICAL Warning (REST): videoId not populated by DAO. XML will have invalid ID.");
            }
            if (video.getCreationDate() == null) {
               video.setCreationDate(new java.sql.Timestamp(System.currentTimeMillis()));
               System.err.println("Warning (REST): creationDate not populated by DAO. Using current system time for XML.");
            }

            Document xmlDoc = generateMetadataXmlDocument(video, authorUsernameForXml);
            try (OutputStream fosXml = Files.newOutputStream(encryptedMetadataPath)) {
                XmlEncryptionUtil.encryptDocument(xmlDoc, fosXml, "Item");
            }

            return Response.status(Response.Status.CREATED).entity(video).build();

        } catch (Exception e) {
            try { Files.deleteIfExists(encryptedVideoPath); } catch (IOException ioe) { System.err.println("Cleanup error for video file (REST): " + ioe.getMessage());}
            try { Files.deleteIfExists(encryptedMetadataPath); } catch (IOException ioe) { System.err.println("Cleanup error for metadata file (REST): " + ioe.getMessage());}
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Processing error during upload: " + e.getMessage() + "\"}").build();
        }
    }

    @GET
    @Path("/stream/{videoId}")
    public Response streamVideo(@PathParam("videoId") int videoId) {
        try {
            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null || video.getFilePath() == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("Video not found").build();
            }
            String videoUploadPath = servletContext.getInitParameter("uploadDirectory");
            if (videoUploadPath == null) {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Config error: Video upload directory not configured.").build();
            }
            
            java.nio.file.Path encryptedVideoPath = Paths.get(videoUploadPath, video.getFilePath());
            if (!Files.exists(encryptedVideoPath)) {
                return Response.status(Response.Status.NOT_FOUND).entity("File not found on server").build();
            }

            String contentType = servletContext.getMimeType("video." + video.getFormat());
            if (contentType == null) {
                contentType = "video/" + video.getFormat();
            }

            StreamingOutput fileStream = output -> {
                try (InputStream eis = Files.newInputStream(encryptedVideoPath)) {
                    EncryptionUtil.decrypt(eis, output);
                } catch (Exception e) {
                    System.err.println("Stream decryption error for videoId " + videoId + ": " + e.getMessage());
                    throw new WebApplicationException("Stream decryption error", e);
                }
            };
            return Response.ok(fileStream).type(contentType).header("Content-Disposition", "inline; filename=\"" + video.getTitle() + "." + video.getFormat() + "\"").build();
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("DB error").build();
        } catch (WebApplicationException e) {
            return e.getResponse();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Streaming error: " + e.getMessage()).build();
        }
    }

    @PUT
    @Path("/incrementViews/{videoId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response incrementViews(@PathParam("videoId") int videoId) {
        try {
            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null || video.getMetadataFilePath() == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("{\"error\":\"Video or metadata path not found.\"}").build();
            }
            String metadataUploadPath = servletContext.getInitParameter("metadataDirectory");
            if (metadataUploadPath == null) {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Config error: Metadata directory not configured.\"}").build();
            }

            java.nio.file.Path encryptedMetadataPath = Paths.get(metadataUploadPath, video.getMetadataFilePath());
            if (!Files.exists(encryptedMetadataPath)) {
                 return Response.status(Response.Status.NOT_FOUND).entity("{\"error\":\"Encrypted XML file not found.\"}").build();
            }

            Document decryptedDoc;
            try (InputStream fis = Files.newInputStream(encryptedMetadataPath)) {
                decryptedDoc = XmlEncryptionUtil.decryptDocument(fis);
            }
            
            int currentDbViews = video.getReproductions();
            videoDAO.incrementReproductions(videoId, video.getMetadataFilePath());
            int newViews = currentDbViews + 1;

            NodeList reproductionsNodes = decryptedDoc.getElementsByTagName("reproducciones");
            if (reproductionsNodes.getLength() > 0) {
                reproductionsNodes.item(0).setTextContent(String.valueOf(newViews));
            } else {
                throw new IOException("Reproducciones tag not found in XML.");
            }
            
            try (OutputStream fos = Files.newOutputStream(encryptedMetadataPath)) {
                XmlEncryptionUtil.encryptDocument(decryptedDoc, fos, "Item");
            }
            
            return Response.ok().entity("{\"message\":\"Views incremented.\"}").build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Error incrementing views: " + e.getMessage() + "\"}").build();
        }
    }
    
    @GET
    @Path("/metadata/{videoId}")
    @Produces(MediaType.APPLICATION_XML)
    public Response downloadMetadataXml(@PathParam("videoId") int videoId) {
        try {
            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null || video.getMetadataFilePath() == null) {
                return Response.status(Response.Status.NOT_FOUND).type(MediaType.APPLICATION_XML).entity("<error>Video or metadata not found</error>").build();
            }
            String metadataUploadPath = servletContext.getInitParameter("metadataDirectory");
            if (metadataUploadPath == null) {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).type(MediaType.APPLICATION_XML).entity("<error>Server configuration error: Metadata directory not configured.</error>").build();
            }

            java.nio.file.Path encryptedXmlPath = Paths.get(metadataUploadPath, video.getMetadataFilePath());
            if (!Files.exists(encryptedXmlPath)) {
                return Response.status(Response.Status.NOT_FOUND).type(MediaType.APPLICATION_XML).entity("<error>Metadata file not found on server</error>").build();
            }

            Document decryptedDoc;
            try (InputStream fis = Files.newInputStream(encryptedXmlPath)) {
                decryptedDoc = XmlEncryptionUtil.decryptDocument(fis);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            TransformerFactory tf = TransformerFactory.newInstance();
            try {
                tf.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
            } catch (javax.xml.transform.TransformerConfigurationException e) {
                 System.err.println("Warning: TransformerFactory does not support FEATURE_SECURE_PROCESSING for XML download: " + e.getMessage());
            }
            Transformer transformer = tf.newTransformer();
            transformer.transform(new DOMSource(decryptedDoc), new StreamResult(baos));
            
            String safeFileName = (video.getTitle() != null ? video.getTitle().replaceAll("[^a-zA-Z0-9.-]", "_") : "metadata");
            return Response.ok(baos.toByteArray()).header("Content-Disposition", "attachment; filename=\"" + safeFileName + "_metadata_" + videoId + ".xml\"").build();
        } catch (Exception e) {
             return Response.status(Response.Status.INTERNAL_SERVER_ERROR).type(MediaType.APPLICATION_XML).entity("<error>Processing error: " + e.getMessage() + "</error>").build();
        }
    }

    @GET
    @Path("/details/{videoId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getVideoDetails(@PathParam("videoId") int videoId) {
        try {
            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("{\"error\":\"Video not found\"}").build();
            }
            return Response.ok(video).build();
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"DB error: " + e.getMessage() + "\"}").build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Unexpected error: " + e.getMessage() + "\"}").build();
        }
    }

    @PUT
    @Path("/update/{videoId}")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateVideoDetails(
            @PathParam("videoId") int videoId,
            @FormParam("title") String title,
            @FormParam("description") String description) {
        try {
            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null || video.getMetadataFilePath() == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("{\"error\":\"Video or its metadata path not found\"}").build();
            }
            if (title == null || title.trim().isEmpty()) {
                 return Response.status(Response.Status.BAD_REQUEST).entity("{\"error\":\"Title cannot be empty.\"}").build();
            }

            boolean dbUpdated = videoDAO.updateVideoDetails(videoId, title, description);
            
            if (dbUpdated) {
                String metadataUploadPath = servletContext.getInitParameter("metadataDirectory");
                if (metadataUploadPath == null) {
                     System.err.println("Error: Metadata directory not configured. XML not updated for videoId: " + videoId);
                     VideoEntity updatedVideoFromDb = videoDAO.getVideoById(videoId);
                     return Response.ok(updatedVideoFromDb).entity("{\"message\":\"Video details updated in DB, but XML update failed due to missing metadataDirectory config.\"}").build();
                }

                java.nio.file.Path encryptedMetadataPath = Paths.get(metadataUploadPath, video.getMetadataFilePath());
                if (!Files.exists(encryptedMetadataPath)) {
                    System.err.println("Error: Encrypted XML file not found. XML not updated for videoId: " + videoId);
                    VideoEntity updatedVideoFromDb = videoDAO.getVideoById(videoId);
                    return Response.ok(updatedVideoFromDb).entity("{\"message\":\"Video details updated in DB, but XML file was not found for update.\"}").build();
                }

                Document decryptedDoc;
                try (InputStream fis = Files.newInputStream(encryptedMetadataPath)) {
                    decryptedDoc = XmlEncryptionUtil.decryptDocument(fis);
                }
                
                NodeList tituloNodes = decryptedDoc.getElementsByTagName("titulo");
                if (tituloNodes.getLength() > 0) {
                    tituloNodes.item(0).setTextContent(title);
                } else {
                     System.err.println("Warning: <titulo> tag not found in XML for videoId " + videoId + ". Title not updated in XML.");
                }

                NodeList descripcionNodes = decryptedDoc.getElementsByTagName("descripcion");
                if (descripcionNodes.getLength() > 0) {
                    descripcionNodes.item(0).setTextContent(description != null ? description : "");
                } else {
                    Element metadataNode = (Element) decryptedDoc.getElementsByTagName("metadata").item(0);
                    if (metadataNode != null) {
                        Element newDescElement = decryptedDoc.createElement("descripcion");
                        newDescElement.setTextContent(description != null ? description : "");
                        metadataNode.appendChild(newDescElement);
                         System.err.println("Info: <descripcion> tag not found, created it for videoId " + videoId);
                    } else {
                         System.err.println("Warning: <metadata> tag not found in XML for videoId " + videoId + ". Description not updated in XML.");
                    }
                }
                
                try (OutputStream fos = Files.newOutputStream(encryptedMetadataPath)) {
                    XmlEncryptionUtil.encryptDocument(decryptedDoc, fos, "Item");
                }
                 System.err.println("XML updated successfully for videoId: " + videoId);
                VideoEntity finalUpdatedVideo = videoDAO.getVideoById(videoId);
                return Response.ok(finalUpdatedVideo).build();
            } else {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Update failed in database.\"}").build();
            }
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"DB error: " + e.getMessage() + "\"}").build();
        } catch (IOException e) {
             return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"File/XML processing error during update: " + e.getMessage() + "\"}").build();
        } catch (Exception e) {
             return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Unexpected error during update: " + e.getMessage() + "\"}").build();
        }
    }
}
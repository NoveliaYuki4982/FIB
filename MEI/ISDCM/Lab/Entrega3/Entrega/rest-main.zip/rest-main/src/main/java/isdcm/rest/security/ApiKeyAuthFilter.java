package isdcm.rest.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;


import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.lang.JoseException;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;

@Provider
public class ApiKeyAuthFilter implements ContainerRequestFilter {

    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";
    private static final String EXPECTED_API_KEY_IN_JWT_CLAIM = SecurityConstants.API_KEY_FOR_JWT;


    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        if ("OPTIONS".equalsIgnoreCase(requestContext.getMethod())) {
            requestContext.abortWith(Response.ok().build());
            return;
        }

        String requestPath = requestContext.getUriInfo().getPath();
        if (("videos/login".equals(requestPath) || "login".equals(requestPath) ) 
            && "POST".equalsIgnoreCase(requestContext.getMethod())) {
            return;
        }
        
        String authHeader = requestContext.getHeaderString(AUTHORIZATION_HEADER);
        if (authHeader == null || !authHeader.startsWith(BEARER_PREFIX)) {
            abortWithUnauthorized(requestContext, "Unauthorized: Authorization header must be provided with Bearer token.");
            return;
        }

        String tokenJWE = authHeader.substring(BEARER_PREFIX.length());

        try {
            JsonWebEncryption jwe = new JsonWebEncryption();
            jwe.setKey(SecurityConstants.JWE_ENCRYPTION_KEY_JOSE4J);
            jwe.setCompactSerialization(tokenJWE);
            String jwsTokenString = jwe.getPlaintextString();

            Jws<Claims> claimsJws = Jwts.parser()
                .setSigningKey(SecurityConstants.JWT_JWS_SECRET_KEY_BYTES)
                .parseClaimsJws(jwsTokenString);
            
            Claims claims = claimsJws.getBody();
            String apiKeyFromToken = claims.get("apiKey", String.class);

            if (apiKeyFromToken == null || !apiKeyFromToken.equals(EXPECTED_API_KEY_IN_JWT_CLAIM)) {
                abortWithUnauthorized(requestContext, "Unauthorized: Invalid API Key in token.");
                return;
            }

        } catch (JoseException e) {
            abortWithUnauthorized(requestContext, "Unauthorized: Token decryption error. " + e.getMessage());
        } catch (ExpiredJwtException e) {
            abortWithUnauthorized(requestContext, "Unauthorized: Token has expired.");
        } catch (SignatureException e) {
             abortWithUnauthorized(requestContext, "Unauthorized: Invalid token signature. " + e.getMessage());
        } catch (MalformedJwtException | UnsupportedJwtException | IllegalArgumentException e) {
            abortWithUnauthorized(requestContext, "Unauthorized: Invalid token format or unsupported token. " + e.getMessage());
        } catch (Exception e) {
            abortWithUnauthorized(requestContext, "Unauthorized: Token processing error. " + e.getMessage());
        }
    }

    private void abortWithUnauthorized(ContainerRequestContext requestContext, String message) {
        requestContext.abortWith(
            Response.status(Response.Status.UNAUTHORIZED)
                    .entity("{\"error\":\"" + message + "\"}")
                    .type(jakarta.ws.rs.core.MediaType.APPLICATION_JSON)
                    .build());
    }
}
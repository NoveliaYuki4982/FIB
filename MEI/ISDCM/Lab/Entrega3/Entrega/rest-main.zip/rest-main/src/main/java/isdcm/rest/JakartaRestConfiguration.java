package isdcm.rest;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;
import isdcm.rest.security.ApiKeyAuthFilter;
import org.glassfish.jersey.media.multipart.MultiPartFeature;

@ApplicationPath("resources")
public class JakartaRestConfiguration extends Application {
    @Override
    public Set<Class<?>> getClasses() {
        final Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(isdcm.rest.resources.JakartaEE91Resource.class);
        classes.add(isdcm.rest.resources.VideoRestService.class);
        classes.add(MultiPartFeature.class);
        classes.add(ApiKeyAuthFilter.class); 
        return classes;
    }
}
package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import isdcm.lowbudgetnetflix.model.User;
import isdcm.lowbudgetnetflix.model.UserEntity;

import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import jakarta.servlet.http.Cookie;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private User userDAO = new User();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        String restApiLoginUrl = "http://localhost:8080/rest/resources/videos/login"; 

        HttpURLConnection conn = null;
        try {
            URL url = new URL(restApiLoginUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setDoOutput(true);

            String urlParameters = "username=" + URLEncoder.encode(username, StandardCharsets.UTF_8.name()) +
                                   "&password=" + URLEncoder.encode(password, StandardCharsets.UTF_8.name());

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = urlParameters.getBytes(StandardCharsets.UTF_8.name());
                os.write(input, 0, input.length);
            }

            int responseCode = conn.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                StringBuilder respBodyBuilder = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8.name()))) {
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        respBodyBuilder.append(responseLine.trim());
                    }
                }
                String responseBody = respBodyBuilder.toString();
                
                Gson gson = new Gson();
                JsonObject jwtResponse = gson.fromJson(responseBody, JsonObject.class);
                String jwtToken = jwtResponse.get("token").getAsString();
                long expiresAtMillis = jwtResponse.get("expiresAt").getAsLong();
                
                UserEntity tempUser = userDAO.authenticateUser(username, password);
                if (tempUser == null) { 
                     request.setAttribute("error", "Session user details could not be retrieved after JWT login.");
                     request.getRequestDispatcher("login.jsp").forward(request, response);
                     return;
                }

                HttpSession session = request.getSession();
                session.setAttribute("user", tempUser);
                
                Cookie jwtCookie = new Cookie("jwt_token", jwtToken);
                jwtCookie.setHttpOnly(true);
                jwtCookie.setSecure(true); 
                jwtCookie.setMaxAge(-1);
                
                String contextPath = request.getContextPath();
                if (contextPath == null || contextPath.isEmpty()) {
                    contextPath = "/";
                }
                jwtCookie.setPath(contextPath);
                
                response.addCookie(jwtCookie);
                response.sendRedirect(request.getContextPath() + "/getVideos");

            } else {
                String errorMsg = "Invalid username or password"; 
                StringBuilder errorBody = new StringBuilder();
                 if (conn.getErrorStream() != null) {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8.name()))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            errorBody.append(line);
                        }
                    }
                    if (errorBody.length() > 0) {
                        try {
                            Gson gson = new Gson();
                            JsonObject errorJson = gson.fromJson(errorBody.toString(), JsonObject.class);
                            if (errorJson.has("error")) {
                                errorMsg = errorJson.get("error").getAsString();
                            } else {
                                errorMsg = "Error from API: " + errorBody.toString();
                            }
                        } catch (Exception parseEx) {
                             errorMsg = "Unparseable error from API: " + errorBody.toString();
                        }
                    } else {
                        errorMsg = "Login failed with HTTP status " + responseCode + " and no error body.";
                    }
                } else {
                     errorMsg = "Login failed with HTTP status " + responseCode + " and no error stream.";
                }
                request.setAttribute("error", errorMsg);
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }

        } catch (SQLException e) {
            request.setAttribute("error", "Database error during login: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } catch (IOException e) {
            request.setAttribute("error", "Could not connect to login service: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "An unexpected error occurred: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
}
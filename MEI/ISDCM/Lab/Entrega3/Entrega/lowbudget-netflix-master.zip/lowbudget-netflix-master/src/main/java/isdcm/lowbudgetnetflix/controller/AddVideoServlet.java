package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.UUID;

import isdcm.lowbudgetnetflix.model.Video;
import isdcm.lowbudgetnetflix.model.UserEntity;
import isdcm.lowbudgetnetflix.model.VideoEntity;
import isdcm.lowbudgetnetflix.model.User;
import isdcm.lowbudgetnetflix.model.EncryptionUtil;
import isdcm.lowbudgetnetflix.model.XmlEncryptionUtil;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


@WebServlet("/addVideo")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10,
                  maxFileSize = 1024 * 1024 * 100,
                  maxRequestSize = 1024 * 1024 * 100)
public class AddVideoServlet extends HttpServlet {
    private Video videoDAO = new Video();
    private User userDAO = new User();

    private Document generateMetadataXmlDocumentInServlet(VideoEntity video, UserEntity authorUser) throws Exception {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        docFactory.setNamespaceAware(true);
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.newDocument();

        Element didlElement = doc.createElementNS("urn:mpeg:mpeg21:2002:02-DIDL-NS", "DIDL");
        doc.appendChild(didlElement);
        didlElement.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
        didlElement.setAttributeNS("http://www.w3.org/2001/XMLSchema-instance", "xsi:schemaLocation", "urn:mpeg:mpeg21:2002:02-DIDL-NS didl.xsd");

        Element itemElement = doc.createElement("Item");
        didlElement.appendChild(itemElement);
        Element componentElement = doc.createElement("Component");
        itemElement.appendChild(componentElement);
        Element descriptorElement = doc.createElement("Descriptor");
        componentElement.appendChild(descriptorElement);
        Element statementElement = doc.createElement("Statement");
        statementElement.setAttribute("mimeType", "text/xml");
        descriptorElement.appendChild(statementElement);
        Element metadataElement = doc.createElement("metadata");
        statementElement.appendChild(metadataElement);

        Element idElement = doc.createElement("id");
        idElement.appendChild(doc.createTextNode(String.valueOf(video.getVideoId())));
        metadataElement.appendChild(idElement);
        Element tituloElement = doc.createElement("titulo");
        tituloElement.appendChild(doc.createTextNode(video.getTitle() != null ? video.getTitle() : ""));
        metadataElement.appendChild(tituloElement);
        Element autorElement = doc.createElement("autor");
        autorElement.appendChild(doc.createTextNode(authorUser != null && authorUser.getUsername() != null ? authorUser.getUsername() : "N/A"));
        metadataElement.appendChild(autorElement);
        Element anyoElement = doc.createElement("anyo");
        anyoElement.appendChild(doc.createTextNode(video.getCreationDateInternal() != null ? String.valueOf(video.getCreationYear()) : "N/A"));
        metadataElement.appendChild(anyoElement);
        Element duracionElement = doc.createElement("duracion");
        duracionElement.appendChild(doc.createTextNode(String.valueOf(video.getLength())));
        metadataElement.appendChild(duracionElement);
        Element reproduccionesElement = doc.createElement("reproducciones");
        reproduccionesElement.appendChild(doc.createTextNode(String.valueOf(video.getReproductions())));
        metadataElement.appendChild(reproduccionesElement);
        Element descripcionElement = doc.createElement("descripcion");
        descripcionElement.appendChild(doc.createTextNode(video.getDescription() != null ? video.getDescription() : ""));
        metadataElement.appendChild(descripcionElement);
        Element resourceElement = doc.createElement("Resource");
        resourceElement.setAttribute("ref", video.getFilePath() != null ? video.getFilePath() : "");
        resourceElement.setAttribute("mimeType", "video/" + (video.getFormat() != null ? video.getFormat() : ""));
        componentElement.appendChild(resourceElement);
        return doc;
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String videoUploadPath = getServletContext().getInitParameter("uploadDirectory");
        String metadataUploadPath = getServletContext().getInitParameter("metadataDirectory");

        if (videoUploadPath == null || metadataUploadPath == null) {
            request.setAttribute("errorMessage", "Upload or metadata directory not configured in web.xml.");
            request.getRequestDispatcher("addVideo.jsp").forward(request, response);
            return;
        }

        File videoUploadDir = new File(videoUploadPath);
        if (!videoUploadDir.exists()) { try { Files.createDirectories(Paths.get(videoUploadPath)); } catch (IOException e) { /* error handling */ } }
        File metadataUploadDir = new File(metadataUploadPath);
        if (!metadataUploadDir.exists()) { try { Files.createDirectories(Paths.get(metadataUploadPath)); } catch (IOException e) { /* error handling */ } }


        UserEntity user = (UserEntity) session.getAttribute("user");
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String lengthStr = request.getParameter("length");
        Part filePart = request.getPart("videoFile");

        if (title == null || title.trim().isEmpty() || lengthStr == null || lengthStr.trim().isEmpty() || filePart == null || filePart.getSize() == 0) {
            request.setAttribute("errorMessage", "Title, length, and video file are required.");
            request.getRequestDispatcher("addVideo.jsp").forward(request, response);
            return;
        }
        
        int length;
        try {
            length = Integer.parseInt(lengthStr);
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid video duration format.");
            request.getRequestDispatcher("addVideo.jsp").forward(request, response);
            return;
        }

        String submittedFileName = filePart.getSubmittedFileName();
        String extension = "";
        int i = submittedFileName.lastIndexOf('.');
        if (i > 0) {
            extension = submittedFileName.substring(i+1).toLowerCase();
        }
        if (extension.isEmpty()){
            request.setAttribute("errorMessage", "File has no extension or invalid filename.");
            request.getRequestDispatcher("addVideo.jsp").forward(request, response);
            return;
        }

        String baseName = UUID.randomUUID().toString();
        String encryptedVideoFileName = baseName + "_video.enc";
        String encryptedMetadataFileName = baseName + "_meta.xml.enc";

        Path fullVideoPath = Paths.get(videoUploadPath, encryptedVideoFileName);
        Path fullMetadataPath = Paths.get(metadataUploadPath, encryptedMetadataFileName);

        VideoEntity video = new VideoEntity();
        video.setTitle(title);
        video.setAuthor(user.getUserId());
        video.setLength(length);
        video.setDescription(description);
        video.setFormat(extension);
        video.setFilePath(encryptedVideoFileName);
        video.setMetadataFilePath(encryptedMetadataFileName);

        UserEntity authorDetails = null;
        
        try (InputStream inputStream = filePart.getInputStream()) {
            authorDetails = userDAO.getUserById(user.getUserId());
            if (authorDetails == null) {
                authorDetails = user;
            }

            System.err.println("[AddVideoServlet] Attempting to save encrypted video to: " + fullVideoPath);
            try (OutputStream fosVideo = Files.newOutputStream(fullVideoPath)) {
                EncryptionUtil.encrypt(inputStream, fosVideo);
            }
            System.err.println("[AddVideoServlet] Encrypted video saved.");

            videoDAO.addVideo(video);
            System.err.println("[AddVideoServlet] Video metadata persisted to DB. VideoID: " + video.getVideoId() + ", CreationDate: " + video.getCreationDateInternal());


            System.err.println("[AddVideoServlet] Generating XML metadata for video ID: " + video.getVideoId());
            Document xmlDoc = generateMetadataXmlDocumentInServlet(video, authorDetails);
            
            System.err.println("[AddVideoServlet] Attempting to save encrypted metadata XML to: " + fullMetadataPath);
            try (OutputStream fosXml = Files.newOutputStream(fullMetadataPath)) {
                XmlEncryptionUtil.encryptDocument(xmlDoc, fosXml, "Item");
            }
            System.err.println("[AddVideoServlet] Encrypted metadata XML saved.");
            
            response.sendRedirect("getVideos?success=Video+uploaded+successfully");

        } catch (SQLException e) {
            cleanupFilesOnError(fullVideoPath, fullMetadataPath);
            request.setAttribute("errorMessage", "Database error during video upload: " + e.getMessage());
            request.getRequestDispatcher("addVideo.jsp").forward(request, response);
        } catch (IOException e) {
            cleanupFilesOnError(fullVideoPath, fullMetadataPath);
            request.setAttribute("errorMessage", "File processing error during video upload: " + e.getMessage());
            request.getRequestDispatcher("addVideo.jsp").forward(request, response);
        } catch (Exception e) {
            cleanupFilesOnError(fullVideoPath, fullMetadataPath);
            request.setAttribute("errorMessage", "An unexpected error has occurred: " + e.getMessage());
            e.printStackTrace(System.err);
            request.getRequestDispatcher("addVideo.jsp").forward(request, response);
        }
    }

    private void cleanupFilesOnError(Path videoPath, Path metadataPath) {
        try {
            if (videoPath != null) Files.deleteIfExists(videoPath);
        } catch (IOException e) {
            System.err.println("Error deleting video file on cleanup: " + videoPath + " - " + e.getMessage());
        }
        try {
            if (metadataPath != null) Files.deleteIfExists(metadataPath);
        } catch (IOException e) {
            System.err.println("Error deleting metadata file on cleanup: " + metadataPath + " - " + e.getMessage());
        }
    }
}
package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Cookie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@WebServlet("/debugJws")
public class DebugJwsServlet extends HttpServlet {

    private static final String REST_API_DEBUG_JWS_URL = "http://localhost:8080/rest/resources/videos/debug-jws";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Cookie[] cookies = request.getCookies();
        String jweToken = null;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("jwt_token".equals(cookie.getName())) {
                    jweToken = cookie.getValue();
                    break;
                }
            }
        }

        if (jweToken == null || jweToken.isEmpty()) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "JWE token not found in cookies. Please log in.");
            return;
        }

        HttpURLConnection conn = null;
        try {
            URL url = new URL(REST_API_DEBUG_JWS_URL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + jweToken);
            conn.setDoOutput(false);

            int responseCode = conn.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                StringBuilder jwsStringBuilder = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        jwsStringBuilder.append(line);
                    }
                }
                String jwsString = jwsStringBuilder.toString();

                response.setContentType("application/jwt");
                response.setHeader("Content-Disposition", "attachment; filename=\"debug_jws_token.jwt\"");
                
                try (OutputStream out = response.getOutputStream()) {
                    out.write(jwsString.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
            } else {
                StringBuilder errorBody = new StringBuilder();
                if (conn.getErrorStream() != null) {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            errorBody.append(line);
                        }
                    }
                }
                response.sendError(responseCode, "Failed to retrieve JWS from API: " + (errorBody.length() > 0 ? errorBody.toString() : conn.getResponseMessage()));
            }

        } catch (IOException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error connecting to debug service: " + e.getMessage());
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
}
package isdcm.lowbudgetnetflix.controller;

import isdcm.lowbudgetnetflix.model.Video;
import isdcm.lowbudgetnetflix.model.VideoEntity;
import isdcm.lowbudgetnetflix.model.UserEntity;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;

@WebServlet("/downloadMetadata")
public class DownloadMetadataXmlServlet extends HttpServlet {
    private Video videoDAO = new Video();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "User not authenticated.");
            return;
        }

        UserEntity loggedInUser = (UserEntity) session.getAttribute("user");

        String videoIdStr = request.getParameter("videoId");
        if (videoIdStr == null || videoIdStr.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing videoId parameter.");
            return;
        }

        try {
            int videoId = Integer.parseInt(videoIdStr);
            
            String metadataPath = getServletContext().getInitParameter("metadataDirectory");
            if (metadataPath == null) {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Metadata directory not configured.");
                return;
            }

            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null || video.getMetadataFilePath() == null) {
                 response.sendError(HttpServletResponse.SC_NOT_FOUND, "Video or metadata file path not found for ID: " + videoId);
                 return;
            }
            
            String safeFileName = video.getTitle() != null ? video.getTitle().replaceAll("[^a-zA-Z0-9.-]", "_") : "metadata";
            String downloadFileName;

            response.setContentType("application/xml");

            if (loggedInUser.getUserId() == video.getAuthor()) {
                downloadFileName = safeFileName +"_metadata_decrypted_" + videoId + ".xml";
                response.setHeader("Content-Disposition", "attachment; filename=\""+ downloadFileName +"\"");

                try (InputStream decryptedXmlStream = videoDAO.getDecryptedMetadataXmlStream(videoId, metadataPath);
                     OutputStream os = response.getOutputStream()) {
                    
                    if (decryptedXmlStream == null) {
                        if (!response.isCommitted()) {
                             response.sendError(HttpServletResponse.SC_NOT_FOUND, "Decrypted metadata stream could not be obtained for video ID: " + videoId);
                        }
                        return;
                    }
                    
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = decryptedXmlStream.read(buffer)) != -1) {
                        os.write(buffer, 0, bytesRead);
                    }
                } catch (IOException e) {
                    System.err.println("Error streaming decrypted XML for videoId " + videoId + ": " + e.getMessage());
                    if (!response.isCommitted()) {
                        if (e.getMessage() != null && (e.getMessage().contains("not found") || e.getMessage().contains("does not exist"))) {
                            response.sendError(HttpServletResponse.SC_NOT_FOUND, e.getMessage());
                        } else {
                            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to provide metadata XML: " + e.getMessage());
                        }
                    }
                } catch (Exception e) { 
                     System.err.println("Unexpected error getting decrypted XML stream for videoId " + videoId + ": " + e.getMessage());
                     if (!response.isCommitted()) {
                        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unexpected error processing metadata: " + e.getMessage());
                    }
                }
            } else {
                downloadFileName = safeFileName +"_metadata_encrypted_" + videoId + ".xml";
                response.setHeader("Content-Disposition", "attachment; filename=\""+ downloadFileName +"\"");

                Path encryptedXmlPath = Paths.get(metadataPath, video.getMetadataFilePath());
                if (!Files.exists(encryptedXmlPath)) {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Encrypted metadata file not found on server.");
                    return;
                }

                try (InputStream fis = Files.newInputStream(encryptedXmlPath);
                     OutputStream os = response.getOutputStream()) {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        os.write(buffer, 0, bytesRead);
                    }
                } catch (IOException e) {
                    System.err.println("Error streaming raw encrypted XML for videoId " + videoId + ": " + e.getMessage());
                    if (!response.isCommitted()) {
                         response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to stream encrypted metadata XML.");
                    }
                }
            }

        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid video ID format.");
        } catch (SQLException e) { 
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error retrieving video details: " + e.getMessage());
        }
    }
}
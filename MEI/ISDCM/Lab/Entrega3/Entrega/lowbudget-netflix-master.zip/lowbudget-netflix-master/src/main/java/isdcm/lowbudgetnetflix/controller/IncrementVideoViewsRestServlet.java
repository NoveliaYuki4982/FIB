package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@WebServlet("/incrementViewsRest")
public class IncrementVideoViewsRestServlet extends HttpServlet {
    private static final String REST_API_URL_INCREMENT_VIEWS = "http://localhost:8080/rest/resources/videos/incrementViews/";

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"success\": false, \"message\": \"User not authenticated.\"}");
            return;
        }

        String videoIdStr = request.getParameter("videoId");
        if (videoIdStr == null || videoIdStr.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"Missing videoId parameter.\"}");
            return;
        }
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String jwtToken = null;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("jwt_token".equals(cookie.getName())) {
                    jwtToken = cookie.getValue();
                    break;
                }
            }
        }
        
        if (jwtToken == null || jwtToken.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"success\": false, \"message\": \"User not authenticated (missing JWT token).\"}");
            return;
        }

        HttpURLConnection conn = null;
        try {
            int videoId = Integer.parseInt(videoIdStr);
            URL url = new URL(REST_API_URL_INCREMENT_VIEWS + videoId);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setDoOutput(true);
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);
            conn.setRequestProperty("Content-Length", "0");

            conn.connect();

            int responseCode = conn.getResponseCode();
            
            InputStream responseStream = (responseCode >= 200 && responseCode < 300) ? conn.getInputStream() : conn.getErrorStream();
            StringBuilder responseBody = new StringBuilder();
            if (responseStream != null) {
                try (java.util.Scanner scanner = new java.util.Scanner(responseStream, StandardCharsets.UTF_8.name())) {
                    if (scanner.hasNext()) {
                       responseBody.append(scanner.useDelimiter("\\A").next());
                    }
                }
            }


            if (responseCode == HttpURLConnection.HTTP_OK) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.getWriter().write("{\"success\": true, \"message\": \"Views incremented successfully.\", \"data\": " + responseBody.toString() + "}");
            } else {
                response.setStatus(responseCode);
                response.getWriter().write("{\"success\": false, \"message\": \"Failed to increment views via API: " + conn.getResponseMessage() + "\", \"details\": \"" + responseBody.toString().replace("\"", "\\\"") + "\"}");
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"Invalid videoId format.\"}");
        } catch (MalformedURLException | ProtocolException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"Error with API URL or protocol: " + e.getMessage() + "\"}");
        } catch (IOException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"Error calling increment views API: " + e.getMessage() + "\"}");
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
}
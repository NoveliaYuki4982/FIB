package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import isdcm.lowbudgetnetflix.model.UserEntity;
import isdcm.lowbudgetnetflix.model.Video;
import isdcm.lowbudgetnetflix.model.VideoEntity;

@WebServlet("/deleteVideo")
public class DeleteVideoServlet extends HttpServlet {
    private Video videoDAO = new Video();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        UserEntity loggedInUser = (UserEntity) session.getAttribute("user");
        
        String videoIdParam = request.getParameter("videoId");
        String message = "";
        
        if (videoIdParam == null || videoIdParam.isEmpty()) {
            message = "error=Invalid+video+ID";
        } else {
            try {
                int videoId = Integer.parseInt(videoIdParam);
                VideoEntity video = videoDAO.getVideoById(videoId);
                
                if (video == null) {
                    message = "error=Video+not+found";
                } else if (video.getAuthor() != loggedInUser.getUserId()) {
                    message = "error=You+are+not+authorized+to+delete+this+video";
                } else {
                    String videoUploadPath = getServletContext().getInitParameter("uploadDirectory");
                    String metadataUploadPath = getServletContext().getInitParameter("metadataDirectory");
                    if (videoUploadPath == null || metadataUploadPath == null) {
                        message = "error=Upload+or+metadata+directory+not+configured";
                    } else {
                        boolean deleted = videoDAO.deleteVideo(videoId, videoUploadPath, metadataUploadPath);
                        if (deleted) {
                            message = "success=Video+deleted+successfully";
                        } else {
                            message = "error=Failed+to+delete+video";
                        }
                    }
                }
            } catch (NumberFormatException e) {
                message = "error=Invalid+video+ID+format";
            } catch (SQLException e) {
                message = "error=Database+error:+" + e.getMessage().replace(" ", "+");
            } catch (IOException e) {
                message = "error=File+system+error:+" + e.getMessage().replace(" ", "+");
            } catch (Exception e) {
                message = "error=An+unexpected+error+occurred";
            }
        }
        response.sendRedirect("getVideos?" + message);
    }
}
package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

@WebServlet("/videos/*")
public class VideoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String uploadPath = getServletContext().getInitParameter("uploadDirectory");
        if (uploadPath == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Upload directory not configured.");
            return;
        }


        String fileName = request.getPathInfo().substring(1); // Remove leading "/"
        File file = new File(uploadPath, fileName);
        if (!file.exists()) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Video not found.");
            return;
        }


        String contentType = "video/" + fileName.substring(fileName.lastIndexOf(".") + 1);
        response.setContentType(contentType);

        try (InputStream in = new FileInputStream(file);
             OutputStream out = response.getOutputStream()) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            throw new ServletException("There was an error while streaming the video", e);
        } catch (Exception ge) {
            throw new ServletException("An unexpected error occurred", ge);
        }
    }
}

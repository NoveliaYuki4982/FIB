package isdcm.lowbudgetnetflix.controller;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import isdcm.lowbudgetnetflix.model.Video;
import isdcm.lowbudgetnetflix.model.VideoEntity;

@WebServlet("/getVideos")
public class GetVideosServlet extends HttpServlet {
    private Video videoDAO = new Video();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String error = request.getParameter("error");
        if (error != null && !error.isEmpty()) {
            request.setAttribute("errorMessage", error);
        }
        
        String success = request.getParameter("success");
        if (success != null && !success.isEmpty()) {
            request.setAttribute("successMessage", success);
        }
        
        try {
            List<VideoEntity> videos = videoDAO.getAllVideos();
            request.setAttribute("videos", videos);
            request.getRequestDispatcher("getVideos.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Database error fetching videos", e);
        } catch (Exception ge) {
            throw new ServletException("An unexpected error occurred", ge);
        }
    }
}
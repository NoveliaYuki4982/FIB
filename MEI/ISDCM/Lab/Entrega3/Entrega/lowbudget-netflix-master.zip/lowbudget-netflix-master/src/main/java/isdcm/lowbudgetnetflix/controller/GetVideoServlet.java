package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.StringJoiner;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;


@WebServlet("/getVideo")
public class GetVideoServlet extends HttpServlet {

    private static final String REST_API_URL =
            "http://localhost:8080/rest/resources/videos";

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String jwtToken = null;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("jwt_token".equals(cookie.getName())) {
                    jwtToken = cookie.getValue();
                    break;
                }
            }
        }

        if (jwtToken == null || jwtToken.isEmpty()) {
            request.setAttribute("errorMessage", "User not authenticated (missing JWT token). Please log in again.");
            request.setAttribute("videosJson", "[]");
            request.getRequestDispatcher("/search.jsp").forward(request, response);
            return;
        }

        StringJoiner query = new StringJoiner("&");
        Map<String,String[]> params = request.getParameterMap();

        for (String p : new String[]{"name", "author", "description", "year", "month",
                                      "day", "orderBy", "orderDir"}) {
            if (params.containsKey(p)) {
                String v = request.getParameter(p);
                if (v != null && !v.isBlank()) {
                    query.add(p + "=" + URLEncoder.encode(
                            v, StandardCharsets.UTF_8));
                }
            }
        }

        String apiUrl = REST_API_URL + (query.length() > 0 ? "?" + query : "");

        HttpURLConnection conn = null;
        String json;

        try {
            conn = (HttpURLConnection) new URL(apiUrl).openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);

            int code = conn.getResponseCode();
            InputStream is = (code == HttpURLConnection.HTTP_OK)
                           ? conn.getInputStream()
                           : conn.getErrorStream();

            json = readAll(is);

            if (code == HttpURLConnection.HTTP_UNAUTHORIZED) {
                 request.setAttribute("errorMessage", "Unauthorized to fetch videos. Your session might have expired. Please log in again.");
                 json = "[]";
            } else if (code != HttpURLConnection.HTTP_OK) {
                request.setAttribute("errorMessage",
                        "API Error (" + code + "): " + json);
                json = "[]";
            }

        } catch (IOException ex) {
            request.setAttribute("errorMessage",
                    "Error contacting video service: " + ex.getMessage());
            json = "[]";
        } finally {
            if (conn != null) conn.disconnect();
        }

        if (json == null || json.isBlank()) json = "[]";

        request.setAttribute("videosJson", json);
        request.getRequestDispatcher("/search.jsp").forward(request, response);
    }

    private static String readAll(InputStream in) throws IOException {
        try (BufferedReader br =
                     new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }
}
package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import isdcm.lowbudgetnetflix.model.Video;

@WebServlet("/incrementViews")
public class IncrementVideoViewsServlet extends HttpServlet {
    private Video videoDAO = new Video();
    
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"success\": false, \"message\": \"User not authenticated.\"}");
            return;
        }
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String videoIdStr = request.getParameter("videoId");
        if (videoIdStr == null || videoIdStr.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"Missing videoId.\"}");
            return;
        }

        try {
            int videoId = Integer.parseInt(videoIdStr);
            String metadataPath = getServletContext().getInitParameter("metadataDirectory");

            if (metadataPath == null) {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"success\": false, \"message\": \"Metadata directory not configured.\"}");
                return;
            }
            videoDAO.incrementReproductions(videoId, metadataPath);
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write("{\"success\": true, \"message\": \"Views incremented successfully.\"}");
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"Invalid videoId format.\"}");
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"Database error: " + e.getMessage() + "\"}");
        } catch (IOException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"File/XML processing error: " + e.getMessage() + "\"}");
        } catch (Exception ge) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"An unexpected error occurred: " + ge.getMessage() + "\"}");
        }
    }
}
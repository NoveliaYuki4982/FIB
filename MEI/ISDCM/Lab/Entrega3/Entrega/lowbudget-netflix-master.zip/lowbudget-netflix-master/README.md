# Lowbudget Netflix

## Project Overview

This project is a web application that mimics some of a video streaming service's basic functionalities, like Netflix. It allows users to register, log in, upload videos, browse and search for videos, play them, and manage their own uploaded content. The application features a user-facing web interface built with JSPs and Servlets, and a RESTful API for video-related operations.

## Features

* **User Management:**
    * User registration ()
    * User login and session management ()
    * User logout ()
    * Username availability check during registration ()
* **Video Management:**
    * **Upload Videos:** Users can upload video files with a title, description, and length. Videos are stored on the server, and metadata is saved in the database. ()
        * Direct upload via web form ()
        * REST API endpoint for uploading videos ()
    * **List Videos:** View a list of all available videos. ()
    * **Search and Filter Videos:** Users can search for videos by title, author (username), and description. Videos can also be filtered by upload date (year, month, day) and sorted by views, release date, title, or author. ()
    * **Play Videos:** Stream videos directly in the browser. ()
        * Video playback page ()
        * Direct video file streaming via `VideoServlet` ()
        * REST API endpoint for video streaming ()
    * **View Video Details:** Get detailed information about a specific video. ()
    * **Update Video Details:** Authenticated users can update the title and description of videos they uploaded. ()
    * **Delete Videos:** Authenticated users can delete videos they uploaded. This removes the video file from the server and its metadata from the database. ()
    * **Increment View Count:** The number of views for a video is incremented when it's played. ()
* **API:**
    * RESTful API for video operations (search, stream, increment views, upload, get details, update details). ()
    * API Key authentication for securing REST endpoints. ()

## Technologies Used

* **Backend:**
    * Java ()
    * Jakarta EE 9.1 (Servlets, JSPs, JAX-RS for REST services) ()
    * Apache Maven for project build and dependency management ()
    * Jersey: JAX-RS (RESTful Web Services) implementation ()
    * Gson: For JSON processing ()
* **Database:**
    * Apache Derby (Embedded database suggested by JDBC URL in `DatabaseConnection.java`) ()
    * SQL for database schema and queries ()
    * Jakarta Persistence (though `persistence.xml` is minimal, suggesting direct JDBC might be more heavily used) ()
* **Frontend:**
    * JSP (Jakarta Server Pages) for dynamic web pages
    * HTML, CSS (), and JavaScript (implied by JSP usage for client-side interactions like AJAX for username check () and video player interactions)
* **Server:**
    * Implicitly a Jakarta EE compatible server like GlassFish (suggested by `glassfish-web.xml` and NetBeans configuration) ()

## Setup and Configuration

1.  **Database Setup:**
    * The application uses an Apache Derby database. ()
    * The database connection details (URL, user, password) are configured in `isdcm.lowbudgetnetflix.model.DatabaseConnection.java`. ()
    * The database schema needs to be initialized using the SQL statements found in `isdcm.lowbudgetnetflix.model.init.sql`. This script creates the `users` and `videos` tables. ()
2.  **Video Upload Directory:**
    * The directory where uploaded videos will be stored needs to be configured.
    * This is set in the `web.xml` file via the `uploadDirectory` context parameter. ()
        ```xml
        <context-param>
            <param-name>uploadDirectory</param-name>
            <param-value>/path/to/your/video_uploads</param-value> </context-param>
        ```
    * Ensure the specified directory exists and the application has write permissions to it. The application attempts to create this directory if it doesn't exist. ()
3.  **API Key:**
    * The REST API endpoints are protected by an API key.
    * The expected API key is hardcoded in `isdcm.lowbudgetnetflix.security.ApiKeyAuthFilter.java` and various client servlets (e.g., `GetVideoServlet`, `AddVideoRestServlet`, `PlayVideoServlet`, `UpdateVideoDetailsServlet`, `IncrementVideoViewsRestServlet`, `GetVideoDetailsServlet`). ()
    * Clients consuming the REST API must include this key in the `X-API-Key` header.
4.  **Maven Dependencies:**
    * The project uses Maven for managing dependencies. Key dependencies include Jakarta EE API, EclipseLink (for JPA, though usage seems minimal), Jersey (for JAX-RS), and Gson. ()

## Project Structure

```
lowbudget-netflix-master/
├── pom.xml                     # Maven Project Object Model: dependencies and build configuration
├── nb-configuration.xml        # NetBeans project specific configuration
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── isdcm/
│   │   │       └── lowbudgetnetflix/
│   │   │           ├── JakartaRestConfiguration.java # Configures JAX-RS application path and registers REST resources & filters
│   │   │           ├── controller/                 # Servlets handling web requests
│   │   │           │   ├── AddVideoRestServlet.java
│   │   │           │   ├── AddVideoServlet.java
│   │   │           │   ├── CheckUsername.java
│   │   │           │   ├── DeleteVideoServlet.java
│   │   │           │   ├── GetVideoDetailsServlet.java
│   │   │           │   ├── GetVideosServlet.java
│   │   │           │   ├── GetVideoServlet.java  # For searching videos via web interface
│   │   │           │   ├── IncrementVideoViewsRestServlet.java
│   │   │           │   ├── IncrementVideoViewsServlet.java
│   │   │           │   ├── LoginServlet.java
│   │   │           │   ├── LogoutServlet.java
│   │   │           │   ├── PlayVideoServlet.java # Streams video to web client by calling REST API
│   │   │           │   ├── RegisterServlet.java
│   │   │           │   ├── UpdateVideoDetailsServlet.java
│   │   │           │   └── VideoServlet.java     # Directly streams video files based on path
│   │   │           ├── model/                      # Data access objects (DAO) and entity classes
│   │   │           │   ├── DatabaseConnection.java # Manages JDBC database connections
│   │   │           │   ├── init.sql                # SQL script for database schema creation
│   │   │           │   ├── User.java               # DAO for user operations (register, auth, check exists)
│   │   │           │   ├── UserEntity.java         # Represents a user
│   │   │           │   ├── Video.java              # DAO for video operations (add, search, get, delete, update, increment views)
│   │   │           │   └── VideoEntity.java        # Represents a video
│   │   │           ├── resources/                  # JAX-RS (REST) resource classes
│   │   │           │   ├── JakartaEE91Resource.java # Sample JAX-RS resource
│   │   │           │   └── VideoRestService.java   # Main REST API for video operations
│   │   │           └── security/
│   │   │               └── ApiKeyAuthFilter.java   # JAX-RS filter for API key authentication
│   │   ├── resources/
│   │   │   └── META-INF/
│   │   │       └── persistence.xml         # JPA configuration (minimal in this project)
│   │   └── webapp/
│   │       ├── WEB-INF/
│   │       │   ├── beans.xml               # CDI configuration
│   │       │   ├── glassfish-web.xml       # GlassFish specific deployment descriptor
│   │       │   └── web.xml                 # Web application deployment descriptor (servlets, filters, context params)
│   │       ├── css/
│   │       │   └── style.css               # Main stylesheet for the web application
│   │       ├── *.jsp                       # JSP files for frontend views (login.jsp, register.jsp, getVideos.jsp, addVideo.jsp, play.jsp, search.jsp, etc.)
└── (other NetBeans or target files)
```

## API Endpoints

The REST API is rooted at `/lowbudgetnetflix/resources`. All endpoints require an `X-API-Key` header for authentication. ()

* **`GET /videos`**: Search and list videos. ()
    * Query Parameters: `name`, `author`, `description`, `year`, `month`, `day`, `orderBy` (views, releaseDate, title, author), `orderDir` (ASC, DESC)
* **`GET /videos/stream/{videoId}`**: Streams the video content for the given `videoId`. ()
    * Produces: `video/mp4` (or other appropriate video MIME type based on file extension)
* **`PUT /videos/incrementViews/{videoId}`**: Increments the reproduction count for the given `videoId`. ()
* **`POST /videos/upload`**: Uploads a new video. ()
    * Consumes: `multipart/form-data`
    * Form Parameters: `title` (String), `description` (String), `length` (int), `author` (int - user ID), `videoFile` (InputStream)
    * Produces: `application/json` (returns the created `VideoEntity`)
* **`GET /videos/details/{videoId}`**: Retrieves details for a specific `videoId`. ()
    * Produces: `application/json` (returns `VideoEntity`)
* **`PUT /videos/update/{videoId}`**: Updates details (title, description) for a specific `videoId`. ()
    * Consumes: `application/x-www-form-urlencoded`
    * Form Parameters: `title` (String), `description` (String)
    * Produces: `application/json` (returns the updated `VideoEntity`)

* **`GET /jakartaee9`**: A sample endpoint for checking Jakarta EE setup. ()

## How to Run (General Guidance)

1.  **Prerequisites:**
    * Java Development Kit (JDK) 11 or higher (as per `maven.compiler.release` in `pom.xml`). ()
    * Apache Maven.
    * A Jakarta EE 9.1 compatible application server (e.g., GlassFish 6.1.0 EE9 as suggested by `nb-configuration.xml`). ()
    * Apache Derby database.
2.  **Configuration:**
    * Set up the Apache Derby database server.
    * Create the database (e.g., `pr2` as per `DatabaseConnection.java`). ()
    * Connect to the database and execute the SQL script in `src/main/java/isdcm/lowbudgetnetflix/model/init.sql` to create the necessary tables. ()
    * Modify the `uploadDirectory` parameter in `src/main/webapp/WEB-INF/web.xml` to a valid path on your server where video files will be stored. ()
    * If running client servlets that call the REST API on a different host/port than the API itself, ensure the API URLs in those servlets are correctly configured (e.g., `REST_API_URL_UPDATE_VIDEO` in `UpdateVideoDetailsServlet.java`). () The current configuration assumes `localhost:8080`.
3.  **Build:**
    * Navigate to the project's root directory (where `pom.xml` is located).
    * Run `mvn clean package` to build the project. This will produce a `.war` file (e.g., `lowbudgetnetflix-1.0.war`) in the `target/` directory.
4.  **Deploy:**
    * Deploy the generated `.war` file to your Jakarta EE application server.
5.  **Access:**
    * Once deployed, the application should be accessible via a web browser. The default welcome page is `login.jsp` (as configured in `web.xml`). () The typical URL might be `http://localhost:8080/lowbudgetnetflix/` (assuming the context path is `lowbudgetnetflix`).

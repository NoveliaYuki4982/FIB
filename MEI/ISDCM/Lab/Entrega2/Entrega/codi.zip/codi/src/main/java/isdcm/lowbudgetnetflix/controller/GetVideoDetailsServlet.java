package isdcm.lowbudgetnetflix.controller;

import isdcm.lowbudgetnetflix.model.VideoEntity;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

@WebServlet("/getVideoDetails")
public class GetVideoDetailsServlet extends HttpServlet {

    private static final String REST_API_URL_VIDEO_DETAILS_BASE = "http://localhost:8080/lowbudgetnetflix/resources/videos/details/";
    private static final String SERVICE_API_KEY = "g5KlCZx8t5hx0xcqLDI87V5hM5vMQeIC6qfWA8vaoOj7hnbDsztImSpuoHEItodDXvfYSEjWk10rkX62mUVqdR9ces2KS59nJvoZIimp5xATmkjOlmBBlrirv0goBm8t";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String videoIdStr = request.getParameter("videoId");
        String errorMessage = null;
        VideoEntity video = null;
        int videoIdForStream = 0;

        if (videoIdStr != null && !videoIdStr.isEmpty()) {
            try {
                videoIdForStream = Integer.parseInt(videoIdStr);
                String apiUrlString = REST_API_URL_VIDEO_DETAILS_BASE + videoIdForStream;
                URL url = new URL(apiUrlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("X-API-Key", SERVICE_API_KEY);

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    StringBuilder respBodyBuilder = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                        String responseLine;
                        while ((responseLine = br.readLine()) != null) {
                            respBodyBuilder.append(responseLine.trim());
                        }
                    }
                    String responseBody = respBodyBuilder.toString();

                    if (responseBody.isEmpty()) {
                        errorMessage = "Video details not found (ID: " + videoIdForStream + ") - API returned empty response.";
                    } else {
                        Gson gson = new GsonBuilder()
                                .setDateFormat("yyyy-MM-dd HH:mm:ss")
                                .create();
                        try {
                            video = gson.fromJson(responseBody, VideoEntity.class);
                            if (video == null) {
                                errorMessage = "Video details not found (ID: " + videoIdForStream + ") or API response was not a valid video entity (parsed as null).";
                            }
                        } catch (JsonSyntaxException e_parser) {
                             errorMessage = "Error parsing video details from API (GSON level). Malformed JSON or type mismatch: " + e_parser.getMessage();
                             video = null;
                        }
                    }
                } else {
                    errorMessage = "Failed to fetch video details from API. Status: " + responseCode + " " + conn.getResponseMessage();
                    InputStream errorStream = conn.getErrorStream();
                    if (errorStream != null) {
                        StringBuilder errorBodyBuilder = new StringBuilder();
                        try (BufferedReader br = new BufferedReader(new InputStreamReader(errorStream, "utf-8"))) {
                            String errorLine;
                            while ((errorLine = br.readLine()) != null) {
                                errorBodyBuilder.append(errorLine.trim());
                            }
                        }
                        errorMessage += " - Details: " + errorBodyBuilder.toString();
                    }
                }
                conn.disconnect();
            } catch (NumberFormatException e) {
                errorMessage = "Invalid video ID format provided: " + videoIdStr;
                videoIdForStream = 0;
            } catch (IOException e) {
                errorMessage = "Error communicating with video details service: " + e.getMessage();
            } catch (Exception e) {
                errorMessage = "An unexpected error occurred while fetching video details: " + e.getMessage();
            }
        } else {
            errorMessage = "No video ID provided for playback.";
        }

        if (video != null) {
            request.setAttribute("video", video);
            request.setAttribute("videoIdForStream", videoIdForStream);
        }
        if (errorMessage != null) {
            request.setAttribute("errorMessage", errorMessage);
        }
        request.setAttribute("videoIdStr", videoIdStr);

        request.getRequestDispatcher("/play.jsp").forward(request, response);
    }
}
package isdcm.lowbudgetnetflix.controller;

import isdcm.lowbudgetnetflix.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/checkUsername")
public class CheckUsername extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        if (username == null || username.trim().isEmpty()) {
            response.getWriter().write("{\"available\": false, \"message\": \"Username cannot be empty\"}");
            return;
        }
        
        try {
            User userModel = new User();
            boolean isAvailable = !userModel.usernameExists(username);
            
            if (isAvailable) {
                response.getWriter().write("{\"available\": true, \"message\": \"Username is available\"}");
            } else {
                response.getWriter().write("{\"available\": false, \"message\": \"Username is already taken\"}");
            }
        } catch (SQLException e) {
            response.getWriter().write("{\"available\": false, \"message\": \"Error checking username\"}");
        } catch (Exception ge) {
            response.getWriter().write("{\"available\": false, \"message\": \"An unexpected error occurred\"}");
        }
    }
}
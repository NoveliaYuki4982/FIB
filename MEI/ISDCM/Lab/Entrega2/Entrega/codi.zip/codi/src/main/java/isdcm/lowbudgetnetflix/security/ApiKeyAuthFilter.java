package isdcm.lowbudgetnetflix.security;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;

@Provider
public class ApiKeyAuthFilter implements ContainerRequestFilter {

    private static final String API_KEY_HEADER = "X-API-Key";
    private static final String EXPECTED_API_KEY = "g5KlCZx8t5hx0xcqLDI87V5hM5vMQeIC6qfWA8vaoOj7hnbDsztImSpuoHEItodDXvfYSEjWk10rkX62mUVqdR9ces2KS59nJvoZIimp5xATmkjOlmBBlrirv0goBm8t";

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        if ("OPTIONS".equalsIgnoreCase(requestContext.getMethod())) {
            requestContext.abortWith(Response.ok().build());
            return;
        }

        String apiKey = requestContext.getHeaderString(API_KEY_HEADER);

        if (apiKey == null || !apiKey.equals(EXPECTED_API_KEY)) {
            requestContext.abortWith(
                Response.status(Response.Status.UNAUTHORIZED)
                      .entity("{\"error\":\"Unauthorized: Missing or invalid API Key.\"}")
                      .type(jakarta.ws.rs.core.MediaType.APPLICATION_JSON)
                      .build());
        }
    }
}
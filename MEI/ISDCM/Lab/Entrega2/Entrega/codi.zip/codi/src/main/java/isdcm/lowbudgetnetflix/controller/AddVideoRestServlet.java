package isdcm.lowbudgetnetflix.controller;

import isdcm.lowbudgetnetflix.model.UserEntity;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@WebServlet("/AddVideoRestServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10,
                 maxFileSize = 1024 * 1024 * 100,
                 maxRequestSize = 1024 * 1024 * 100)
public class AddVideoRestServlet extends HttpServlet {

    private static final String REST_API_UPLOAD_URL = "http://localhost:8080/lowbudgetnetflix/resources/videos/upload";
    private static final String SERVICE_API_KEY = "g5KlCZx8t5hx0xcqLDI87V5hM5vMQeIC6qfWA8vaoOj7hnbDsztImSpuoHEItodDXvfYSEjWk10rkX62mUVqdR9ces2KS59nJvoZIimp5xATmkjOlmBBlrirv0goBm8t";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"success\": false, \"message\": \"User not authenticated.\"}");
            return;
        }

        UserEntity user = (UserEntity) session.getAttribute("user");
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String lengthStr = request.getParameter("length");
        Part filePart = request.getPart("videoFile");

        if (title == null || title.trim().isEmpty() || lengthStr == null || lengthStr.trim().isEmpty() || filePart == null || filePart.getSize() == 0) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"Missing required fields (title, length, video file).\"}");
            return;
        }

        int length;
        try {
            length = Integer.parseInt(lengthStr);
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"Invalid video duration format.\"}");
            return;
        }
        
        String submittedFileName = filePart.getSubmittedFileName(); 
        String boundary = "Boundary-" + System.currentTimeMillis() + "-" + Long.toHexString(Double.doubleToLongBits(Math.random()));
        
        HttpURLConnection httpConn = null;

        try {
            URL url = new URL(REST_API_UPLOAD_URL);
            httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setUseCaches(false);
            httpConn.setDoOutput(true); 
            httpConn.setDoInput(true);
            httpConn.setRequestMethod("POST");
            String contentTypeHeader = "multipart/form-data; boundary=" + boundary; 
            httpConn.setRequestProperty("Content-Type", contentTypeHeader);
            httpConn.setRequestProperty("X-API-Key", SERVICE_API_KEY);

            try (OutputStream outputStream = httpConn.getOutputStream();
                 InputStream inputStream = filePart.getInputStream()) {
                
                addFormField(outputStream, boundary, "title", title);
                addFormField(outputStream, boundary, "description", description != null ? description : "");
                addFormField(outputStream, boundary, "length", String.valueOf(length));
                addFormField(outputStream, boundary, "author", String.valueOf(user.getUserId()));

                String fileFieldName = "videoFile";
                String partHeader;
                
                partHeader = "--" + boundary + "\r\n";
                outputStream.write(partHeader.getBytes(StandardCharsets.UTF_8));

                partHeader = "Content-Disposition: form-data; name=\"" + fileFieldName + "\"; filename=\"" + submittedFileName + "\"\r\n";
                outputStream.write(partHeader.getBytes(StandardCharsets.UTF_8));
                
                String resolvedContentType = filePart.getContentType();
                if (resolvedContentType == null || resolvedContentType.isEmpty() || resolvedContentType.equalsIgnoreCase("application/octet-stream")) {
                    resolvedContentType = getServletContext().getMimeType(submittedFileName);
                    if (resolvedContentType == null || resolvedContentType.isEmpty()) {
                        resolvedContentType = "application/octet-stream"; 
                    }
                }
                partHeader = "Content-Type: " + resolvedContentType + "\r\n";
                outputStream.write(partHeader.getBytes(StandardCharsets.UTF_8));

                partHeader = "\r\n"; 
                outputStream.write(partHeader.getBytes(StandardCharsets.UTF_8));

                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead); 
                }
                outputStream.flush(); 
                
                partHeader = "\r\n"; 
                outputStream.write(partHeader.getBytes(StandardCharsets.UTF_8));
            
                partHeader = "--" + boundary + "--\r\n";
                outputStream.write(partHeader.getBytes(StandardCharsets.UTF_8));
            } 

            int status = httpConn.getResponseCode();
            
            StringBuilder responseBody = new StringBuilder();
            InputStream responseStream = (status >= 200 && status < 300) ? httpConn.getInputStream() : httpConn.getErrorStream();
            if (responseStream != null) {
                try (java.util.Scanner scanner = new java.util.Scanner(responseStream, StandardCharsets.UTF_8.name())) {
                    if (scanner.hasNext()) { 
                       responseBody.append(scanner.useDelimiter("\\A").next());
                    }
                }
            }

            if (status == HttpURLConnection.HTTP_OK || status == HttpURLConnection.HTTP_CREATED) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.getWriter().write("{\"success\": true, \"message\": \"Video uploaded successfully.\", \"data\": " + escapeJson(responseBody.toString()) + "}");
            } else {
                response.setStatus(status); 
                response.getWriter().write("{\"success\": false, \"message\": \"Failed to upload video to REST service. Status: " + status + ", Response: " + escapeJson(responseBody.toString()) + "\"}");
            }

        } catch (IOException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"Error communicating with REST service: " + e.getMessage() + "\"}");
        } finally {
            if (httpConn != null) {
                httpConn.disconnect();
            }
        }
    }

    private void addFormField(OutputStream outputStream, String boundary, String name, String value) throws IOException {
        String partData;
        
        partData = "--" + boundary + "\r\n";
        outputStream.write(partData.getBytes(StandardCharsets.UTF_8));

        partData = "Content-Disposition: form-data; name=\"" + name + "\"\r\n";
        outputStream.write(partData.getBytes(StandardCharsets.UTF_8));

        partData = "\r\n"; 
        outputStream.write(partData.getBytes(StandardCharsets.UTF_8));

        outputStream.write(value.getBytes(StandardCharsets.UTF_8));

        partData = "\r\n"; 
        outputStream.write(partData.getBytes(StandardCharsets.UTF_8));
    }
    
    private String escapeJson(String S) {
        if (S == null || S.isEmpty()) {
            return "\"\""; 
        }
        return "\"" + S.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\b", "\\b")
                .replace("\f", "\\f")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t") + "\"";
    }
}
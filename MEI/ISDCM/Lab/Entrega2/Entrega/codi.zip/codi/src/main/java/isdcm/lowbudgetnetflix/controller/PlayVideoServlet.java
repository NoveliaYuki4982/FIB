package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet("/playVideo")
public class PlayVideoServlet extends HttpServlet {

    private static final String REST_API_URL_STREAM = "http://localhost:8080/lowbudgetnetflix/resources/videos/stream/";
    private static final String SERVICE_API_KEY = "g5KlCZx8t5hx0xcqLDI87V5hM5vMQeIC6qfWA8vaoOj7hnbDsztImSpuoHEItodDXvfYSEjWk10rkX62mUVqdR9ces2KS59nJvoZIimp5xATmkjOlmBBlrirv0goBm8t"; 


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        String videoIdStr = request.getParameter("videoId");
        if (videoIdStr == null || videoIdStr.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing videoId parameter.");
            return;
        }

        try {
            int videoId = Integer.parseInt(videoIdStr);
            URL url = new URL(REST_API_URL_STREAM + videoId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("X-API-Key", SERVICE_API_KEY);

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                String contentType = conn.getContentType();
                response.setContentType(contentType != null ? contentType : "video/mp4");

                try (InputStream inputStream = conn.getInputStream();
                     OutputStream outputStream = response.getOutputStream()) {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, bytesRead);
                    }
                }
            } else {
                response.sendError(responseCode, "Failed to stream video from API: " + conn.getResponseMessage());
            }
            conn.disconnect();
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid videoId format.");
        } catch (IOException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error streaming video: " + e.getMessage());
        }
    }
}
package isdcm.lowbudgetnetflix.model;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class VideoEntity {
    private int videoId;
    private String title;
    private int author;
    private String authorUsername;
    private Timestamp creationDate;
    private int length;
    private int reproductions;
    private String description;
    private String format;
    private String filePath;

    public int getVideoId() { return videoId; }
    public void setVideoId(int videoId) { this.videoId = videoId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public int getAuthor() { return author; }
    public void setAuthor(int author) { this.author = author; }
    
    public String getAuthorUsername() { return authorUsername; }
    public void setAuthorUsername(String authorUsername) { this.authorUsername = authorUsername; }
    
    public String getCreationDate() {
        if (this.creationDate == null) {
            return null; 
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return dateFormat.format(this.creationDate);
    }
    public void setCreationDate(Timestamp creationDate) { this.creationDate = creationDate; }

    public Timestamp getCreationDateInternal() {
        return this.creationDate;
    }
    
    public int getLength() { return length; }
    public void setLength(int length) { this.length = length; }
    
    public int getReproductions() { return reproductions; }
    public void setReproductions(int reproductions) { this.reproductions = reproductions; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }
    
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
}
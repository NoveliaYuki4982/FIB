package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/UpdateVideoDetailsServlet")
public class UpdateVideoDetailsServlet extends HttpServlet {
    private static final String REST_API_URL_UPDATE_VIDEO = "http://localhost:8080/lowbudgetnetflix/resources/videos/update";
    private static final String SERVICE_API_KEY = "g5KlCZx8t5hx0xcqLDI87V5hM5vMQeIC6qfWA8vaoOj7hnbDsztImSpuoHEItodDXvfYSEjWk10rkX62mUVqdR9ces2KS59nJvoZIimp5xATmkjOlmBBlrirv0goBm8t"; 

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"success\": false, \"message\": \"User not authenticated.\"}");
            return;
        }

        Map<String, String> parameters = new HashMap<>();
        StringBuilder requestBody = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(request.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                requestBody.append(line);
            }
        }

        String[] pairs = requestBody.toString().split("&");
        for (String pair : pairs) {
            int idx = pair.indexOf("=");
            if (idx > 0 && idx < pair.length() - 1) {
                parameters.put(URLDecoder.decode(pair.substring(0, idx), StandardCharsets.UTF_8.name()),
                               URLDecoder.decode(pair.substring(idx + 1), StandardCharsets.UTF_8.name()));
            } else if (idx == -1 && !pair.isEmpty()){
                 parameters.put(URLDecoder.decode(pair, StandardCharsets.UTF_8.name()), "");
            }
        }

        String videoIdStr = parameters.get("videoId");
        String title = parameters.get("title");
        String description = parameters.get("description");


        if (videoIdStr == null || videoIdStr.isEmpty() || title == null || title.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"Missing videoId or title.\"}");
            return;
        }

        HttpURLConnection conn = null;
        try {
            int videoId = Integer.parseInt(videoIdStr);
            URL url = new URL(REST_API_URL_UPDATE_VIDEO + "/" + videoId);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
            conn.setRequestProperty("X-API-Key", SERVICE_API_KEY);

            String postData = "title=" + URLEncoder.encode(title, StandardCharsets.UTF_8.name()) +
                              "&description=" + URLEncoder.encode(description != null ? description : "", StandardCharsets.UTF_8.name());

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = postData.getBytes(StandardCharsets.UTF_8.name());
                os.write(input, 0, input.length);
            }

            int responseCode = conn.getResponseCode();
            StringBuilder responseApiBody = new StringBuilder();
            InputStreamReader streamReader = null;
            
            if (responseCode >= 200 && responseCode < 300) {
                streamReader = new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8);
            } else {
                 if(conn.getErrorStream() != null){
                    streamReader = new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8);
                 }
            }

            if (streamReader != null) {
                try (BufferedReader br = new BufferedReader(streamReader)) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        responseApiBody.append(line);
                    }
                }
            }


            if (responseCode == HttpURLConnection.HTTP_OK) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.getWriter().write("{\"success\": true, \"message\": \"Video updated successfully.\", \"data\": " + (responseApiBody.length() > 0 ? responseApiBody.toString() : "\"\"") + "}");
            } else {
                response.setStatus(responseCode);
                response.getWriter().write("{\"success\": false, \"message\": \"Failed to update video via API. Status: " + responseCode + "\", \"details\": " + (responseApiBody.length() > 0 ? responseApiBody.toString() : "\"\"") + "}");
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"Invalid videoId format.\"}");
        } catch (IOException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"Error calling update video API: " + e.getMessage() + "\"}");
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
}
package isdcm.lowbudgetnetflix.resources;

import isdcm.lowbudgetnetflix.model.Video;
import isdcm.lowbudgetnetflix.model.VideoEntity;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.StreamingOutput;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;


@Path("/videos")
public class VideoRestService {

    private final Video videoDAO = new Video();

    @Context
    private ServletContext servletContext;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response searchVideos(
            @QueryParam("name") String name,
            @QueryParam("author") String author,
            @QueryParam("description") String description,
            @QueryParam("year") Integer year,
            @QueryParam("month") Integer month,
            @QueryParam("day") Integer day,
            @QueryParam("orderBy") String orderBy,
            @QueryParam("orderDir") String orderDir) {

        try {
            List<VideoEntity> videos = videoDAO.searchVideos(name, author, description, year, month, day, orderBy, orderDir);
            return Response.ok(videos).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity("{\"error\":\"Invalid query parameter: " + e.getMessage() + "\"}").build();
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Database error: " + e.getMessage() + "\"}").build();
        } catch (Exception e) {
            e.printStackTrace(); 
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Unexpected error during video search: " + e.getMessage() + "\"}").build();
        }
    }

    @GET
    @Path("/stream/{videoId}")
    @Produces("video/mp4")
    public Response streamVideo(@PathParam("videoId") int videoId) {
        try {
            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("Video not found (ID: " + videoId + ")").build();
            }

            String uploadPath = servletContext.getInitParameter("uploadDirectory");
            if (uploadPath == null) {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Upload directory not configured.").build();
            }

            File videoFile = new File(uploadPath, video.getFilePath());
            if (!videoFile.exists() || !videoFile.isFile()) {
                return Response.status(Response.Status.NOT_FOUND).entity("Video file not found on server: " + video.getFilePath()).build();
            }

            String contentType = servletContext.getMimeType(videoFile.getName());
            if (contentType == null) {
                contentType = "application/octet-stream";
                String fileName = videoFile.getName().toLowerCase();
                 if (fileName.endsWith(".mp4")) contentType = "video/mp4";
                else if (fileName.endsWith(".webm")) contentType = "video/webm";
                else if (fileName.endsWith(".ogv") || fileName.endsWith(".ogg")) contentType = "video/ogg";
            }


            StreamingOutput fileStream = output -> {
                try (InputStream input = new FileInputStream(videoFile)) {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = input.read(buffer)) != -1) {
                        output.write(buffer, 0, bytesRead);
                    }
                    output.flush();
                } catch (IOException e) {
                    throw new WebApplicationException("Error streaming video file.", e, Response.Status.INTERNAL_SERVER_ERROR);
                }
            };

            return Response.ok(fileStream)
                            .header("Content-Disposition", "inline; filename=\"" + videoFile.getName() + "\"")
                            .type(contentType)
                            .build();

        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Database error retrieving video: " + e.getMessage()).build();
        } catch (WebApplicationException e) {
            return e.getResponse(); 
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unexpected error streaming video: " + e.getMessage()).build();
        }
    }

    @PUT
    @Path("/incrementViews/{videoId}")
    public Response incrementViews(@PathParam("videoId") int videoId) {
        try {
            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null) {
                 return Response.status(Response.Status.NOT_FOUND).entity("{\"error\":\"Video not found for incrementing views (ID: " + videoId + ")\"}").build();
            }
            videoDAO.incrementReproductions(videoId);
            return Response.ok().entity("{\"message\":\"Views incremented for video " + videoId + "\"}").build();
        } catch (SQLException e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Database error incrementing views: " + e.getMessage() + "\"}").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Unexpected error incrementing views: " + e.getMessage() + "\"}").build();
        }
    }

    @POST
    @Path("/upload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    public Response uploadVideo(
            @FormDataParam("title") String title,
            @FormDataParam("description") String description,
            @FormDataParam("length") int length,
            @FormDataParam("author") int authorId,
            @FormDataParam("videoFile") InputStream uploadedInputStream,
            @FormDataParam("videoFile") FormDataContentDisposition fileDetail) {
        
        if (title == null || title.trim().isEmpty() || length <= 0 || authorId <= 0 || uploadedInputStream == null || fileDetail == null || fileDetail.getFileName() == null || fileDetail.getFileName().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST).entity("{\"error\":\"Missing or invalid parameters for video upload.\"}").build();
        }

        String uploadPath = servletContext.getInitParameter("uploadDirectory");
        if (uploadPath == null) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Upload directory not configured.\"}").build();
        }

        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            if (!uploadDir.mkdirs()) {
                 return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Failed to create upload directory: "+ uploadPath +"\"}").build();
            }
        }
        
        String originalFileName = fileDetail.getFileName();
        String extension = "";
        int i = originalFileName.lastIndexOf('.');
        if (i > 0) {
            extension = originalFileName.substring(i+1).toLowerCase();
        }
        if (extension.isEmpty()){
            return Response.status(Response.Status.BAD_REQUEST).entity("{\"error\":\"File has no extension.\"}").build();
        }

        String newFileName = UUID.randomUUID().toString() + "." + extension;
        String filePath = Paths.get(uploadPath, newFileName).toString();

        try {
            Files.copy(uploadedInputStream, Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Error saving uploaded file: " + e.getMessage() + "\"}").build();
        }

        VideoEntity video = new VideoEntity();
        video.setTitle(title);
        video.setAuthor(authorId);
        video.setLength(length);
        video.setDescription(description);
        video.setFormat(extension);
        video.setFilePath(newFileName);

        try {
            videoDAO.addVideo(video);
            return Response.status(Response.Status.CREATED).entity(video).build();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                Files.deleteIfExists(Paths.get(filePath));
            } catch (IOException ex) {
                System.err.println("Failed to delete orphaned file after DB error: " + ex.getMessage());
            }
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Database error during video upload: " + e.getMessage() + "\"}").build();
        }
    }
    
    @GET
    @Path("/details/{videoId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getVideoDetails(@PathParam("videoId") int videoId) {
        try {
            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null) {
                return Response.status(Response.Status.NOT_FOUND)
                                   .entity("{\"error\":\"Video not found with ID: " + videoId + "\"}")
                                   .build();
            }
            return Response.ok(video).build();
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity("{\"error\":\"Database error: " + e.getMessage() + "\"}")
                           .build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity("{\"error\":\"Unexpected error: " + e.getMessage() + "\"}")
                           .build();
        }
    }

    @PUT
    @Path("/update/{videoId}")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateVideoDetails(
            @PathParam("videoId") int videoId,
            @FormParam("title") String title,
            @FormParam("description") String description) {
        try {
            VideoEntity video = videoDAO.getVideoById(videoId);
            if (video == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("{\"error\":\"Video not found (ID: " + videoId + ")\"}").build();
            }
            
            if (title == null || title.trim().isEmpty()) {
                 return Response.status(Response.Status.BAD_REQUEST).entity("{\"error\":\"Title cannot be empty.\"}").build();
            }

            boolean updated = videoDAO.updateVideoDetails(videoId, title, description);
            if (updated) {
                VideoEntity updatedVideo = videoDAO.getVideoById(videoId);
                return Response.ok(updatedVideo).build();
            } else {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Failed to update video details in database.\"}").build();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Database error updating video: " + e.getMessage() + "\"}").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{\"error\":\"Unexpected error updating video: " + e.getMessage() + "\"}").build();
        }
    }
}
package isdcm.lowbudgetnetflix.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Video {

    public void addVideo(VideoEntity video) throws SQLException {
        String sql = "INSERT INTO videos (title, author, length, description, format, filePath) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, video.getTitle());
            ps.setInt(2, video.getAuthor());
            ps.setInt(3, video.getLength());
            ps.setString(4, video.getDescription());
            ps.setString(5, video.getFormat());
            ps.setString(6, video.getFilePath());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    video.setVideoId(rs.getInt(1));
                }
            }
        }
    }
    
    public List<VideoEntity> searchVideos(
            String name, String author, String description,
            Integer year, Integer month, Integer day,
            String orderBy, String orderDir) throws SQLException, IllegalArgumentException {

        List<VideoEntity> videos = new ArrayList<>();
        StringBuilder sqlBuilder = new StringBuilder("SELECT v.*, u.username FROM videos v JOIN users u ON v.author = u.userId WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (name != null && !name.isEmpty()) {
            sqlBuilder.append(" AND LOWER(v.title) LIKE ?");
            params.add("%" + name.toLowerCase() + "%");
        }

        if (author != null && !author.isEmpty()) {
            sqlBuilder.append(" AND LOWER(u.username) LIKE ?");
            params.add("%" + author.toLowerCase() + "%");
        }
        
        if (description != null && !description.isEmpty()) {
            sqlBuilder.append(" AND LOWER(v.description) LIKE ?");
            params.add("%" + description.toLowerCase() + "%");
        }

        if (year != null) {
            sqlBuilder.append(" AND YEAR(v.creationDate) = ?");
            params.add(year);
        }

        if (month != null) {
            sqlBuilder.append(" AND MONTH(v.creationDate) = ?");
            params.add(month);
        }

        if (day != null) {
            sqlBuilder.append(" AND DAY(v.creationDate) = ?");
            params.add(day);
        }

        if (orderBy != null && !orderBy.isEmpty()) {
            String sortColumn;
            switch (orderBy.toLowerCase()) {
                case "views":
                    sortColumn = "v.reproductions";
                    break;
                case "releasedate":
                    sortColumn = "v.creationDate";
                    break;
                case "title":
                    sortColumn = "v.title";
                    break;
                case "author":
                    sortColumn = "u.username";
                    break;
                default:
                    throw new IllegalArgumentException("Invalid orderBy parameter: " + orderBy + 
                            ". Allowed values are: views, releaseDate, title, author.");
            }

            String direction = "ASC";
            if (orderDir != null) {
                if (orderDir.equalsIgnoreCase("DESC")) {
                    direction = "DESC";
                } else if (!orderDir.equalsIgnoreCase("ASC")) {
                    throw new IllegalArgumentException("Invalid orderDir parameter: " + orderDir + 
                            ". Allowed values are: ASC, DESC.");
                }
            }
            sqlBuilder.append(" ORDER BY ").append(sortColumn).append(" ").append(direction);
        } else {
            sqlBuilder.append(" ORDER BY v.creationDate DESC");
        }


        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sqlBuilder.toString())) {

            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    VideoEntity video = new VideoEntity();
                    video.setVideoId(rs.getInt("videoId"));
                    video.setTitle(rs.getString("title"));
                    video.setAuthor(rs.getInt("author"));
                    video.setAuthorUsername(rs.getString("username"));
                    video.setCreationDate(rs.getTimestamp("creationDate"));
                    video.setLength(rs.getInt("length"));
                    video.setReproductions(rs.getInt("reproductions"));
                    video.setDescription(rs.getString("description"));
                    video.setFormat(rs.getString("format"));
                    video.setFilePath(rs.getString("filePath"));
                    videos.add(video);
                }
            }
        }
        return videos;
    }

    public List<VideoEntity> getAllVideos() throws SQLException {
        return searchVideos(null, null, null, null, null, null, "releaseDate", "DESC");
    }
    
    public void incrementReproductions(int videoId) throws SQLException {
        String sql = "UPDATE videos SET reproductions = reproductions + 1 WHERE videoId = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, videoId);
            ps.executeUpdate();
        }
    }
    
    public VideoEntity getVideoById(int videoId) throws SQLException {
        String sql = "SELECT v.*, u.username FROM videos v JOIN users u ON v.author = u.userId WHERE v.videoId = ?";
        VideoEntity video = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, videoId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    video = new VideoEntity();
                    video.setVideoId(rs.getInt("videoId"));
                    video.setTitle(rs.getString("title"));
                    video.setAuthor(rs.getInt("author"));
                    video.setAuthorUsername(rs.getString("username"));
                    video.setCreationDate(rs.getTimestamp("creationDate"));
                    video.setLength(rs.getInt("length"));
                    video.setReproductions(rs.getInt("reproductions"));
                    video.setDescription(rs.getString("description"));
                    video.setFormat(rs.getString("format"));
                    video.setFilePath(rs.getString("filePath"));
                }
            }
        }
        return video;
    }

    public boolean deleteVideo(int videoId) throws SQLException {
        String sql = "DELETE FROM videos WHERE videoId = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, videoId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }

    public boolean updateVideoDetails(int videoId, String title, String description) throws SQLException {
        String sql = "UPDATE videos SET title = ?, description = ? WHERE videoId = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setInt(3, videoId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }
}
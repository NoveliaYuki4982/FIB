CREATE TABLE users (
    userId INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    name VARCHAR(50) NOT NULL,
    surname VARCHAR(50) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(64) NOT NULL,
    email VARCHAR(100)

CREATE TABLE videos (
    videoId INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    title VARCHAR(100) NOT NULL,
    author INT NOT NULL,
    creationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    length INT NOT NULL,
    reproductions INT DEFAULT 0,
    description VARCHAR(255),
    format VARCHAR(10) NOT NULL,
    filePath VARCHAR(255) NOT NULL,
    FOREIGN KEY (author) REFERENCES users(userId) ON DELETE CASCADE
);
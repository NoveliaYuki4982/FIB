package isdcm.lowbudgetnetflix.controller;

import isdcm.lowbudgetnetflix.exceptions.InsecurePasswordException;
import isdcm.lowbudgetnetflix.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String email = request.getParameter("email");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String password2 = request.getParameter("password2");
        
        try {
            checkIsValidPassword(password);
            if (!password.equals(password2)) {
                request.setAttribute("error", "Passwords do not match");
                request.getRequestDispatcher("register.jsp").forward(request, response);
                return;
            }
            User userModel = new User();
            userModel.registerUser(name, surname, username, password, email);
            response.sendRedirect("login.jsp");
        } catch (InsecurePasswordException pe) {
            request.setAttribute("error", "Registration failed: " + pe.printMessage());
            request.getRequestDispatcher("register.jsp").forward(request, response);
        } catch (SQLException e) {
            request.setAttribute("error", "Registration failed: " + e.getMessage());
            request.getRequestDispatcher("register.jsp").forward(request, response);
        } catch (Exception ge) {
            request.setAttribute("error", "An unexpected error occurred: " + ge.getMessage());
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }
        
    private void checkIsValidPassword(String password) throws InsecurePasswordException {
        if (password.length() < 8 || password.length() > 64) 
            throw new InsecurePasswordException(1);

        int digitCount = 0;
        int specialCharCount = 0;
        boolean hasUpperCase = false;
        boolean hasLowerCase = false;

        // Loop through each character of the password
        for (char c : password.toCharArray()) {
            // Check if the character is a digit
            if (Character.isDigit(c)) {
                digitCount++;
            }
            // Check if the character is a special character
            else if (!Character.isLetterOrDigit(c)) {
                specialCharCount++;
            }
            // Check if the character is an uppercase letter
            if (Character.isUpperCase(c)) {
                hasUpperCase = true;
            }
            // Check if the character is a lowercase letter
            if (Character.isLowerCase(c)) {
                hasLowerCase = true;
            }

            // If all conditions are met early, return true
            if (digitCount >= 2 && specialCharCount >= 2 && hasUpperCase && hasLowerCase) {
                return;
            }
        }
        
        if (!hasLowerCase) throw new InsecurePasswordException(2);
        if (!hasUpperCase) throw new InsecurePasswordException(3);
        if (digitCount < 2) throw new InsecurePasswordException(4);
        if (specialCharCount < 2) throw new InsecurePasswordException(5);
    }
}
package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import isdcm.lowbudgetnetflix.model.UserEntity;
import isdcm.lowbudgetnetflix.model.Video;
import isdcm.lowbudgetnetflix.model.VideoEntity;

@WebServlet("/deleteVideo")
public class DeleteVideoServlet extends HttpServlet {
    private Video videoDAO = new Video();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        UserEntity loggedInUser = (UserEntity) session.getAttribute("user");
        
        String videoIdParam = request.getParameter("videoId");
        String message = "";
        
        if (videoIdParam == null || videoIdParam.isEmpty()) {
            message = "error=Invalid+video+ID";
        } else {
            try {
                int videoId = Integer.parseInt(videoIdParam);
                
                VideoEntity video = videoDAO.getVideoById(videoId);
                
                if (video == null) {
                    message = "error=Video+not+found";
                } else if (video.getAuthor() != loggedInUser.getUserId()) {
                    message = "error=You+are+not+authorized+to+delete+this+video";
                } else {
                    String uploadPath = getServletContext().getInitParameter("uploadDirectory");
                    if (uploadPath == null) {
                        message = "error=Upload+directory+not+configured";
                    } else {
                        String filePath = video.getFilePath();
                        Path fileToDelete = Paths.get(uploadPath + File.separator + filePath);
                        
                        boolean fileDeleted = false;
                        try {
                            if (Files.exists(fileToDelete)) {
                                Files.delete(fileToDelete);
                                fileDeleted = true;
                            } else {
                                fileDeleted = true;
                                log("Warning: Video file not found: " + fileToDelete.toString());
                            }
                        } catch (IOException e) {
                            log("Error deleting file: " + e.getMessage(), e);
                        } catch (Exception ge) {
                            log("An unexpected error occurred: " + ge.getMessage(), ge);
                        }
                        
                        boolean dbDeleted = videoDAO.deleteVideo(videoId);
                        
                        if (dbDeleted && fileDeleted) {
                            message = "success=Video+deleted+successfully";
                        } else if (dbDeleted) {
                            message = "success=Video+record+deleted,+but+the+file+could+not+be+removed";
                        } else {
                            message = "error=Failed+to+delete+video+from+database";
                        }
                    }
                }
            } catch (NumberFormatException e) {
                message = "error=Invalid+video+ID+format";
            } catch (SQLException e) {
                message = "error=Database+error:+" + e.getMessage().replace(" ", "+");
            } catch (Exception e) {
                message = "An unexpected error occurred";
            }
        }
        
        response.sendRedirect("getVideos?" + message);
    }
}
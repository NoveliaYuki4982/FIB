package isdcm.lowbudgetnetflix.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Video {

    public void addVideo(VideoEntity video) throws SQLException {
        String sql = "INSERT INTO videos (title, author, length, description, format, filePath) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, video.getTitle());
            ps.setInt(2, video.getAuthor());
            ps.setInt(3, video.getLength());
            ps.setString(4, video.getDescription());
            ps.setString(5, video.getFormat());
            ps.setString(6, video.getFilePath());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    video.setVideoId(rs.getInt(1));
                }
            }
        }
    }
    
    public List<VideoEntity> getAllVideos() throws SQLException {
        List<VideoEntity> videos = new ArrayList<>();
        String sql = "SELECT v.*, u.username FROM videos v JOIN users u ON v.author = u.userId";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                VideoEntity video = new VideoEntity();
                video.setVideoId(rs.getInt("videoId"));
                video.setTitle(rs.getString("title"));
                video.setAuthor(rs.getInt("author"));
                video.setAuthorUsername(rs.getString("username"));
                video.setCreationDate(rs.getTimestamp("creationDate"));
                video.setLength(rs.getInt("length"));
                video.setReproductions(rs.getInt("reproductions"));
                video.setDescription(rs.getString("description"));
                video.setFormat(rs.getString("format"));
                video.setFilePath(rs.getString("filePath"));
                videos.add(video);
            }
        }
        return videos;
    }
    
    public void incrementReproductions(int videoId) throws SQLException {
        String sql = "UPDATE videos SET reproductions = reproductions + 1 WHERE videoId = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, videoId);
            ps.executeUpdate();
        }
    }
    
    public VideoEntity getVideoById(int videoId) throws SQLException {
        String sql = "SELECT v.*, u.username FROM videos v JOIN users u ON v.author = u.userId WHERE v.videoId = ?";
        VideoEntity video = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, videoId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    video = new VideoEntity();
                    video.setVideoId(rs.getInt("videoId"));
                    video.setTitle(rs.getString("title"));
                    video.setAuthor(rs.getInt("author"));
                    video.setAuthorUsername(rs.getString("username"));
                    video.setCreationDate(rs.getTimestamp("creationDate"));
                    video.setLength(rs.getInt("length"));
                    video.setReproductions(rs.getInt("reproductions"));
                    video.setDescription(rs.getString("description"));
                    video.setFormat(rs.getString("format"));
                    video.setFilePath(rs.getString("filePath"));
                }
            }
        }

        return video;
    }

    public boolean deleteVideo(int videoId) throws SQLException {
        String sql = "DELETE FROM videos WHERE videoId = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, videoId);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }
}
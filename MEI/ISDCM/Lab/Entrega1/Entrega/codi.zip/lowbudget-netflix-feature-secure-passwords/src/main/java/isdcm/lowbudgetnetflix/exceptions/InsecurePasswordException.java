/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isdcm.lowbudgetnetflix.exceptions;

/**
 *
 * @author alumne
 */
public class InsecurePasswordException extends Exception {
    int conditionViolated = 0;
    
    public InsecurePasswordException(int conditionViolated) 
    { 
        super("Insecure Password: "); 
        this.conditionViolated = conditionViolated; 
    } 
    
    public String printMessage() {
        switch (conditionViolated) {
            case 1:
                return "Password length should be between 8 to 64 characters";
            case 2:
                return "Password should contain at least one lower case letter";
            case 3:
                return "Password should contain at least one upper case letter";
            case 4:
                return "Password should contain at least two digits";
            case 5:
                return "Password should contain at least two special characters";
        }
        
        return "";
    }
}

package isdcm.lowbudgetnetflix.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.UUID;
import isdcm.lowbudgetnetflix.model.Video;
import isdcm.lowbudgetnetflix.model.UserEntity;
import isdcm.lowbudgetnetflix.model.VideoEntity;

@WebServlet("/addVideo")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10,
                 maxFileSize = 1024 * 1024 * 100,
                 maxRequestSize = 1024 * 1024 * 100)
public class AddVideoServlet extends HttpServlet {
    private Video videoDAO = new Video();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String uploadPath = getServletContext().getInitParameter("uploadDirectory");
        if (uploadPath == null) {
            throw new ServletException("Upload directory not configured in web.xml.");
        }

        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            try {
                Files.createDirectories(Paths.get(uploadPath));
            } catch (IOException e) {
                throw new ServletException("Failed to create upload directory: " + uploadPath, e);
            } catch (Exception ge) {
                throw new ServletException("An unexpected error occurred", ge);
            }
        }

        UserEntity user = (UserEntity) session.getAttribute("user");
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        int length = Integer.parseInt(request.getParameter("length"));
        Part filePart = request.getPart("videoFile");
        String submittedFileName = filePart.getSubmittedFileName();
        String extension = submittedFileName.substring(submittedFileName.lastIndexOf(".") + 1);
        String fileName = UUID.randomUUID().toString() + "." + extension;
        String fullFilePath = uploadPath + File.separator + fileName;

        try (InputStream inputStream = filePart.getInputStream()) {
            File destFile = new File(fullFilePath);
            Files.copy(inputStream, destFile.toPath());
        }

        VideoEntity video = new VideoEntity();
        video.setTitle(title);
        video.setAuthor(user.getUserId());
        video.setLength(length);
        video.setDescription(description);
        video.setFormat(extension);
        video.setFilePath(fileName);

        try {
            videoDAO.addVideo(video);
            response.sendRedirect("getVideos");
        } catch (SQLException e) {
            throw new ServletException("Database error during video upload", e);
        } catch (Exception ge) {
            throw new ServletException("An unexpecteed error has occurred", ge);
        }
    }
}